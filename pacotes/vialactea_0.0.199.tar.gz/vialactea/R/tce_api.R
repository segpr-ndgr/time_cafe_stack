#' Função para acessar a API do TCE
#'
#' Esta função realiza uma requisição GET para a API do TCE de Pernambuco e retorna o conteúdo da resposta.
#'
#' @param path O caminho da API para acessar.
#' @param query Uma lista de parâmetros de consulta para a requisição. Padrão é NULL.
#' @return Um objeto da classe `tce_api` contendo o status, entidade, tamanho do resultado, limite do resultado e conteúdo da resposta.
#' @examples
#' tce_api("DadosAbertos/Contratos!json", list(ID_UNIDADE_GESTORA = "510101"))
#' @export
tce_api <- function(path, query = NULL) {

  response <- httr2::request("https://sistemas.tce.pe.gov.br") |>
    # Then we add on the  path
    httr2::req_url_path_append(path) |>
    # Add query parameters
    httr2::req_url_query(!!!query) |>
    httr2::req_retry(max_tries = 3) %>%
    httr2::req_perform()

  if (httr2::resp_content_type(response) != "application/json") {
    stop("API não retornou formato json", call. = FALSE)
  }

  parsed <- response |>
    httr2::resp_body_string(encoding = "ISO-8859-1") %>%
    jsonlite::fromJSON() %>% pluck("resposta")

  if (httr2::resp_is_error(response)) {
    stop(
      sprintf(
        "TCE API requisição obteve falha [%s]\n%s\n<%s>",
        httr2::resp_status(response),
        parsed$message,
        parsed$documentation_url
      ),
      call. = FALSE
    )
  }

  structure(
    list(
      status = parsed %>% pluck("status"),
      entidade = parsed  %>% pluck("entidade"),
      tamanhoResultado = parsed %>% pluck("tamanhoResultado"),
      limiteResultado = parsed %>% pluck("limiteResultado"),
      conteudo = parsed %>% pluck("conteudo") %>% as_tibble(),
      path = path,
      response = response
    ),
    class = "tce_api"
  )
}

#' Função para obter contratos da API do TCE
#'
#' Esta função retorna os contratos da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo dos contratos.
#' @examples
#' contratos_api(list(ID_UNIDADE_GESTORA = "510101"))
#' @export
contratos_api <- function(query) {
  path = "DadosAbertos/Contratos!json"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter aditivos da API do TCE
#'
#' Esta função retorna os aditivos da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo dos aditivos.
#' @examples
#' aditivos_api(list(ID_UNIDADE_GESTORA = "510101"))
#' @export
aditivos_api <- function(query) {
  path = "DadosAbertos/TermoAditivo!json"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter itens de contrato da API do TCE
#'
#' Esta função retorna os itens de contrato da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo dos itens de contrato.
#' @examples
#' itens_contrato_api(list(ID_UNIDADE_GESTORA = "510101"))
#' @export
itens_contrato_api <- function(query) {
  path = "DadosAbertos/ContratoItemObjeto!json"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter despesas estaduais da API do TCE
#'
#' Esta função retorna as despesas estaduais da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo das despesas estaduais.
#' @examples
#' despesas_estaduais_api(list(ID_UNIDADE_GESTORA = "510101"))
#' @export
despesas_estaduais_api <- function(query) {
  path = "DadosAbertos/DespesasEstaduais!json"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter resumo de empenhos da API do TCE
#'
#' Esta função retorna o resumo de empenhos da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo do resumo de empenhos.
#' @examples
#' resumo_empenho_api(list(ID_UNIDADE_GESTORA = "510101", NUMEROEMPENHO = "2020NE000111"))
#' @export
resumo_empenho_api <- function(query) {
  path = "DadosAbertos/EmpenhoResumo!json?"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter liquidações de empenho da API do TCE
#'
#' Esta função retorna as liquidações de empenho da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo das liquidações de empenho.
#' @examples
#' liquidacao_empenho_api(list(NUMEROEMPENHO = "2020NE000111", ID_UNIDADE_GESTORA = "510101"))
#' @export
liquidacao_empenho_api <- function(query) {
  path = "DadosAbertos/EmpenhoLiquidacao!json?"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter pagamentos de empenho da API do TCE
#'
#' Esta função retorna os pagamentos de empenho da API do TCE de Pernambuco.
#'
#' @param query Uma lista de parâmetros de consulta para a requisição.
#' @return Um tibble contendo o conteúdo dos pagamentos de empenho.
#' @examples
#' pagamento_empenho_api(list(ID_UNIDADE_GESTORA = "510101", NUMEROEMPENHO = "2020NE000111"))
#' @export
pagamento_empenho_api <- function(query) {
  path = "DadosAbertos/EmpenhoPagamento!json?"
  resp <- tce_api(path, query)
  return(resp$conteudo)
}

#' Função para obter unidades gestoras estaduais da API do TCE
#'
#' Esta função retorna as unidades gestoras estaduais da API do TCE de Pernambuco.
#'
#' @return Um tibble contendo o conteúdo das unidades gestoras estaduais.
#' @examples
#' unidades_gestoras_api()
#' @export
unidades_gestoras_api <- function() {
  path = "DadosAbertos/UnidadesJurisdicionadasEstaduais!json"
  resp <- tce_api(path)
  return(resp$conteudo)
}

#' Função para obter unidades jurisdicionadas da API do TCE
#'
#' Esta função retorna as unidades jurisdicionadas da API do TCE de Pernambuco.
#'
#' @return Um tibble contendo o conteúdo das unidades jurisdicionadas.
#' @examples
#' unidades_jurisdicionadas_api()
#' @export
unidades_jurisdicionadas_api <- function() {
  path = "DadosAbertos/UnidadesJurisdicionadas!json"
  resp <- tce_api(path, query = "ESFERA=E")
  return(resp$conteudo)
}
