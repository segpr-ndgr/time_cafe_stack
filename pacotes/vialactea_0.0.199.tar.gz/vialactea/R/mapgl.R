#' @title Menu de Camadas Customizado
#' @description Gera um dropdown com checkboxes para seleção múltipla e radio buttons para escolha exclusiva.
#' @param inputId ID do input (string). Este ID será processado por NS() internamente.
#' @param label (opcional) Texto ou conteúdo HTML a ser exibido no botão do dropdown.
#' @param layers Vetor nomeado com as camadas a serem exibidas como checkboxes.
#'   Exemplo: `c("waze-points" = "Alertas Waze", "SRE" = "SRE", "PCI" = "PCI")`.
#'   Se NULL, nenhum checkbox será exibido.
#' @param tooltip (opcional) Texto do tooltip a ser aplicado ao botão do dropdown.
#' @param options Vetor nomeado com as opções a serem exibidas como radio buttons.
#'   Exemplo: `c("option1" = "Opção A", "option2" = "Opção B")`.
#'   Se NULL, nenhum radio será exibido.
#' @param initial_layers Vetor de caracteres com os valores das layers que devem estar selecionadas inicialmente.
#'   Se NULL (padrão) e se *layers* for fornecido, todos os itens de *layers* serão marcados.
#' @param initial_option Valor (string) que indica qual opção de *options* deve ficar selecionada inicialmente.
#'   Se NULL (padrão) e se *options* for fornecido, o primeiro item de *options* será marcado.
#' @return Um objeto tagList que pode ser incluído na UI.
#' @export
#' @examples
#' if (interactive()) {
#'   library(shiny)
#'   ui <- fluidPage(
#'     menuCamadasInput("menuCamadas",
#'       label = "Selecione Camadas",
#'       layers = c("waze-points" = "Alertas Waze",
#'                  "SRE" = "SRE",
#'                  "PCI" = "PCI",
#'                  "Nomes" = "Nomes",
#'                  "Pernambuco" = "Pernambuco"),
#'       options = c("option1" = "Opção A", "option2" = "Opção B"),
#'       tooltip = "Clique para selecionar as camadas",
#'       initial_layers = c("waze-points", "PCI"),
#'       initial_option = "option2"
#'     )
#'   )
#'   server <- function(input, output, session) {
#'     observe({
#'       cat("Camadas selecionadas:", input$menuCamadas_layers, "\n")
#'       cat("Opção selecionada:", input$menuCamadas_options, "\n")
#'     })
#'   }
#'   shinyApp(ui, server)
#' }
menuCamadasInput <- function(inputId,
                             label = NULL,
                             layers,
                             tooltip = NULL,
                             options,
                             initial_layers = NULL,
                             initial_option = NULL) {

  # Cria o namespace internamente
  ns <- shiny::NS(inputId)

  # Define os nomes dos inputs reativos que serão atualizados via JavaScript.
  # Esses nomes são baseados no inputId original (já encapsulado fora da função).
  idCamadas <- paste0(inputId, "_layers")
  idOpcao   <- paste0(inputId, "_options")

  # Se initial_layers for NULL, considera que todas as layers devem vir marcadas.
  if (!is.null(layers) && is.null(initial_layers)) {
    initial_layers <- names(layers)
  }

  # Cria os itens de checkbox se 'layers' for fornecido
  layers_ui <- NULL
  if (!is.null(layers) && length(layers) > 0) {
    layers_ui <- lapply(seq_along(layers), function(i) {
      value <- names(layers)[i]
      label_layer <- layers[i]
      checked_attr <- if (value %in% initial_layers) "checked" else NULL

      shiny::tags$li(
        shiny::tags$span(
          class = "dropdown-item", #href = "#",
          div(
            class = "form-check",
            shiny::tags$input(
              class = "form-check-input input-controle-camada",
              id = ns(paste0("layer_", value)),
              type = "checkbox",
              value = value,
              checked = checked_attr
            ),
            shiny::tags$label(
              class = "form-check-label",
              `for` = ns(paste0("layer_", value)),
              style = "padding-left: 5px; font-size: 90%;",
              label_layer
            )
          )
        )
      )
    })
  }

  # Cria os itens de radio se 'options' for fornecido
  options_ui <- NULL
  if (!is.null(options) && length(options) > 0) {
    radioName <- ns("menu_radio")  # Todos os radios devem compartilhar o mesmo atributo "name"
    options_ui <- lapply(seq_along(options), function(i) {
      value <- names(options)[i]
      label_option <- options[i]
      checked_attr <- if (!is.null(initial_option)) {
        if (value == initial_option) "checked" else NULL
      } else {
        if (i == 1) "checked" else NULL
      }

      shiny::tags$li(
        div(
          class = "dropdown-item",
          div(
            class = "form-check",
            shiny::tags$input(
              class = "form-check-input input-controle-radio",
              id = ns(paste0("radio_option", i)),
              type = "radio",
              name = radioName,
              value = value,
              checked = checked_attr
            ),
            shiny::tags$label(
              class = "form-check-label",
              `for` = ns(paste0("radio_option", i)),
              style = "padding-left: 5px; font-size: 90%;",
              label_option
            )
          )
        )
      )
    })
  }

  # Combina os itens de checkbox e radio; se ambos existirem, insere um divisor entre eles.
  dropdown_items <- list()
  if (!is.null(layers_ui)) {
    dropdown_items <- c(dropdown_items, layers_ui)
  }
  if (!is.null(layers_ui) && !is.null(options_ui)) {
    dropdown_items <- c(dropdown_items, list(shiny::tags$li(shiny::tags$hr(class = "dropdown-divider"))))
  }
  if (!is.null(options_ui)) {
    dropdown_items <- c(dropdown_items, options_ui)
  }

  # Se tooltip for fornecido, adiciona-o ao botão
  if (!is.null(tooltip))
    icon_bottom <-  shiny::HTML('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                      viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                      stroke-linecap="round" stroke-linejoin="round">
                      <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                      <polyline points="2 17 12 22 22 17"></polyline>
                      <polyline points="2 12 12 17 22 12"></polyline>
                      </svg>') |> tooltip(tooltip, options = list(trigger = "hover"))
  else
    icon_bottom <-  shiny::HTML('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                      viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                      stroke-linecap="round" stroke-linejoin="round">
                      <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                      <polyline points="2 17 12 22 22 17"></polyline>
                      <polyline points="2 12 12 17 22 12"></polyline>
                      </svg>')

  menu <- div(
      id = ns("container"),
      div(
        class = "dropdown",
        shiny::tags$button(
          class = "btn btn-primary dropdown-toggle d-flex",
          style = "height: 32px;",
          type = "button",
          id = ns("dropdownControleCamadas"),
          `data-bs-toggle` = "dropdown",
          `aria-expanded` = "false",
          # Ícone SVG customizado
          icon_bottom,
          label
        ),
        shiny::tags$ul(
          class = "dropdown-menu",
          `aria-labelledby` = ns("dropdownControleCamadas"),
          dropdown_items
        )
      )
    )



  # Cria o menu dropdown completo
  ui_menu <- tagList(
    menu,
    # Script para atualizar o input reativo 'inputId_layers' com os valores dos checkboxes selecionados
    shiny::tags$script(HTML(sprintf("
      $(document).on('change', '#%s .input-controle-camada', function() {
        var selected = [];
        $('#%s .input-controle-camada:checked').each(function() {
          selected.push($(this).val());
        });
        Shiny.setInputValue('%s', selected);
      });
    ", ns("container"), ns("container"), idCamadas))),

    # Script para atualizar o input reativo 'inputId_options' com o valor selecionado dos radio buttons
    shiny::tags$script(HTML(sprintf("
      $(document).on('change', '#%s .input-controle-radio', function() {
        var selected = $('#%s .input-controle-radio:checked').val();
        Shiny.setInputValue('%s', selected);
      });
    ", ns("container"), ns("container"), idOpcao))),

    # Script para inicializar os inputs no Shiny com os valores fornecidos, após a conexão
    shiny::tags$script(HTML(sprintf("
      $(document).on('shiny:connected', function() {
        setTimeout(function(){
          Shiny.setInputValue('%s', %s, {priority: 'event'});
          Shiny.setInputValue('%s', '%s', {priority: 'event'});
        }, 100);
      });
    ",
                                    idCamadas,
                                    jsonlite::toJSON(initial_layers, auto_unbox = TRUE),
                                    idOpcao,
                                    if (!is.null(initial_option)) initial_option else ""
    )))
  )

  ui_menu
}

#' Atualiza o menu de camadas (checkboxes) e opção (radios)
#'
#' @param session Objeto session do Shiny
#' @param inputId Mesmo inputId que você usou em menuCamadasInput()
#' @param selected_layers Vetor de caracteres com as layers a serem marcadas.
#'                        Se NULL, nenhuma será marcada.
#' @param selected_option String com o valor do radio a ser marcado. Se NULL, nenhum será marcado.
#' @export
updateMenuCamadasInput <- function(session, inputId,
                                   selected_layers = NULL,
                                   selected_option = NULL) {
  ns <- session$ns
  # Vamos precisar do ID do container para achar os elementos no DOM
  #container_id <- paste0(ns(inputId), "-container")
  container_id <- ns("container")
  msg <- list(
    containerId = container_id,
    layers      = selected_layers %||% list(),
    option      = selected_option %||% ""
  )
  session$sendCustomMessage("menuCamadas:update", msg)
}


##' @title Atualiza menuCamadasInput em módulo
#' @description Marca/desmarca checkboxes e radio do menuCamadasInput()
#' @param session Objeto session do Shiny (no server do módulo)
#' @param inputId O mesmo inputId passado a menuCamadasInput(), sem namespace
#' @param selected_layers Vetor de layers a marcar (pode ser string única também)
#' @param selected_option Valor do radio a marcar
#' @export
updateMenuCamadasInput <- function(session, inputId,
                                   selected_layers  = NULL,
                                   selected_option  = NULL) {
  # no módulo, session$ns(inputId) => "<namespace>-<inputId>"
  container_id <- paste0(session$ns(inputId), "-container")

  msg <- list(
    containerId = container_id,
    layers      = selected_layers,
    option      = selected_option
  )
  session$sendCustomMessage("menuCamadas:update", msg)
}


#' @title Carrega JS do Vialactea para menuCamadasInput
#' @export
use_vialactea <- function() {
  tags$head(
    tags$script(HTML("
      Shiny.addCustomMessageHandler('menuCamadas:update', function(msg) {
        //console.log('[menuCamadas:update] recebido:', msg);

        // garante sempre array
        var layers = msg.layers;
        if (!Array.isArray(layers)) {
          layers = layers ? [layers] : [];
        }
        //console.log(' → layers array:', layers);

        // procura o container correto
        var $ctr = $('#' + msg.containerId);
        //console.log(' → container encontrado?', $ctr.length, msg.containerId);

        // atualiza checkboxes
        var $chk = $ctr.find('.input-controle-camada');
        //console.log(' → checboxes encontrados:', $chk.length);
        $chk.prop('checked', false);
        layers.forEach(function(v){
          console.log('    marcando:', v);
          $chk.filter('[value=\"'+v+'\"]').prop('checked', true);
        });
        $chk.trigger('change');

        // atualiza radio
        var $rad = $ctr.find('.input-controle-radio');
        //console.log(' → radios encontrados:', $rad.length, 'option=', msg.option);
        $rad.prop('checked', false);
        if (msg.option) {
          $rad.filter('[value=\"'+ msg.option +'\"]').prop('checked', true);
        }
        $rad.trigger('change');

        //console.log('→ menuCamadas:update concluído');
      });
    "))
  )
}
