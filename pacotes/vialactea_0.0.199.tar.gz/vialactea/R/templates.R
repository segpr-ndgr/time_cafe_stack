# This function showcases how one might write a function to be used as an
# RStudio project template. This function will be called when the user invokes
# the New Project wizard using the project template defined in the template file
# at:
#
#
#
# The function itself just echos its inputs and outputs to a file called INDEX,
# which is then opened by RStudio when the new project is opened.
create_report_binder <- function(path, use_git, use_report,
                                 use_talk, use_app, use_press,
                                 use_autor, use_processor, use_officialletter, ...) {

  # ensure path exists
  dir.create(path, recursive = TRUE, showWarnings = FALSE)

  # collect inputs and paste together as 'Parameter: Value'
  dots <- list(...)

  if (use_git) {
    git2r::init(path)
  }

  if (use_report) {
    if(!dir.exists(paste0(path, "/report")))
      dir.create(paste0(path, "/report"))

    vialactea::use_quarto_ext(path, ext_name = "report")
    file.copy(
      from = system.file("extdata/_extensions/report/skeleton.qmd", package = "vialactea"),
      to = paste0(path, "/report/index.qmd"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
    file.copy(
      from = system.file("extdata/_extensions/report/references.bib", package = "vialactea"),
      to = paste0(path, "/report/references.bib"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
    if (use_processor == "Governo de Pernambuco") {
      file.copy(
        from = system.file("extdata/_extensions/report/govpe_report.tex", package = "vialactea"),
        to = paste0(path, "/report/_extensions/report/report.tex"),
        overwrite = TRUE,
        copy.mode = TRUE
      )
      file.copy(
        from = system.file("extdata/_extensions/report/FUNDO_BRANCO.png", package = "vialactea"),
        to = paste0(path, "/report/_extensions/report/FUNDO_BRANCO.png"),
        overwrite = TRUE,
        copy.mode = TRUE
      )
    } else {
      file.copy(
        from = system.file("extdata/_extensions/report/sepe_report.tex", package = "vialactea"),
        to = paste0(path, "/report/_extensions/report/report.tex"),
        overwrite = TRUE,
        copy.mode = TRUE
      )
    }

  }

  if (use_talk) {
    if(!dir.exists(paste0(path, "/talk")))
      dir.create(paste0(path, "/talk"))
    if(!dir.exists(paste0(path, "/talk/images")))
      dir.create(paste0(path, "/talk/images"))
    vialactea::use_quarto_ext(path, ext_name = "talk")
    file.copy(
      from = system.file("extdata/_extensions/talk/skeleton.qmd", package = "vialactea"),
      to = paste0(path, "/talk/index.qmd"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
    file.copy(
      from = system.file("extdata/_extensions/talk/PoorEconomics.jpg", package = "vialactea"),
      to = paste0(path, "/talk/images/PoorEconomics.jpg"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
    if (use_processor == "Governo de Pernambuco") {
      file.copy(
        from = system.file("extdata/_extensions/talk/govpe_styles.css", package = "vialactea"),
        to = paste0(path, "/talk/_extensions/talk/styles.css"),
        overwrite = TRUE,
        copy.mode = TRUE
      )
    }
    # file.copy(
    #   from = system.file("extdata/_extensions/fullscreen", package = "vialactea"),
    #   to = paste0(path, "/talk/_extension/"),
    #   overwrite = TRUE,
    #   recursive = TRUE,
    #   copy.mode = TRUE
    # )
    fs::file_move(
      path = paste0(path, "/talk/_extensions/talk/data"),
      new_path = paste0(path, "/talk/")
    )
  }

  if (use_press) {
    if (!dir.exists(paste0(path, "/press")))
      dir.create(paste0(path, "/press"))
    vialactea::use_quarto_ext(path, ext_name = "press")
    file.copy(
      from = system.file("extdata/_extensions/press/template.qmd", package = "vialactea"),
      to = paste0(path, "/press/press.qmd"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
  }

  if (use_app) {
    # copy from internals
    if(!dir.exists(paste0(path, "/app"))) dir.create("app")
    fs::dir_copy(
      path =  system.file(paste0("extdata/_extensions/app/"), package = "vialactea"),
      new_path = paste0(path, "/app/")
    )
  }

  if(!dir.exists(paste0(path, "/scripts"))) dir.create(paste0(path, "/scripts"))
  if(!dir.exists(paste0(path, "/references"))) dir.create(paste0(path, "/references"))
  if(!dir.exists(paste0(path, "/data"))) dir.create(paste0(path, "/data"))
  if(!dir.exists(paste0(path, "/legacy"))) dir.create(paste0(path, "/legacy"))

  contents <- c(
    "# Este script, chamado \"random_codes.R\", é apenas um repositório",
    "# de códigos aleatórios sem sequência lógica, apenas para testes",
    "# Nos outros arquivos SEJA ORGANIZADO, documente seu código e não crie problemas!",
    "# Just kidding. Enjoy!",
    "# Diretórios:",
    "#    report: use o arquivo index.qmd para user o modelo.",
    "#    talk: use o arquivo index.qmd para user o modelo.",
    "#    press: use o arquivo press.qmd para user o modelo.",
    "#    app: use os arquivo ui.R e server.R.",
    "#    scrips: códigos aleatórios usados em testes.",
    "#    references: documentos de interesse como dicionários e referências.",
    "#    data: bases de dados em qualquer formato.",
    "#    legacy: arquivos que não seram mais utilizados ou versões antigas. "
  )
  # write to file
  writeLines(paste(contents, collapse = "\n"),
             con = file.path(path, "/scripts/random_codes.R"))
}





#' Efeito para as capas das seções
#' @param path escoloha noma da pasta
#' @param name nome da pasta
#' @param organization ainda nao implementado
#' @return TRUE se tudo ok
#' @export
create_report_skeleton <- function(nome, path = ".", organization = "SEPE", ...) {

  # ensure path exists
  if(!dir.exists(paste0(path, "/", nome))) {
    dir.create(paste0(path, "/", nome), recursive = TRUE, showWarnings = FALSE)
    message("Created base folder")
    dir.create(paste0(path, "/" , nome, "/_extensions"))
    message("Created '_extensions' folder")
  } else {
    stop("Directory already exists!")
  }

  #   # collect inputs and paste together as 'Parameter: Value'
#   dots <- list(...)

  # various reading of key-value pairs for reporting
  ext_yml <- readLines(system.file(paste0("extdata/_extensions/report/_extension.yml"), package = "vialactea"),
                       n = 3)

  ext_ver <- gsub(
    x = ext_yml[grepl(x = ext_yml, pattern = "version:")],
    pattern = "version: ",
    replacement = ""
  )

  ext_nm <- gsub(
    x = ext_yml[grepl(x = ext_yml, pattern = "title:")],
    pattern = "title: ",
    replacement = ""
  )

  # copy from internals
  file.copy(
    from = system.file(paste0("extdata/_extensions/report"), package = "vialactea"),
    to = paste0(path, "/" , nome, "/_extensions/"),
    overwrite = TRUE,
    recursive = TRUE,
    copy.mode = TRUE
  )

  # logic check to make sure extension files were moved
  n_files <- length(dir(paste0(path, "/" , nome, "/_extensions/report")))

  if(n_files >= 2){
    message(paste(ext_nm, "v.", ext_ver, "foi instalado no diretório \"_extensions\"."))
  } else {
    message("Aparentemente a extensão não foi encontrada.")
  }

  file.copy(
      from = system.file("extdata/_extensions/report/skeleton.qmd", package = "vialactea"),
      to = paste0(path, "/", nome, "/", "index.qmd"),
      overwrite = TRUE,
      copy.mode = TRUE
  )

  file.copy(
    from = system.file("extdata/_extensions/report/references.bib", package = "vialactea"),
    to = paste0(path, "/", nome, "/", "references.bib"),
    overwrite = TRUE,
    copy.mode = TRUE
  )
  if (organization == "Governo de Pernambuco") {
    file.copy(
      from = system.file("extdata/_extensions/report/govpe_report.tex", package = "vialactea"),
      to = paste0(path,  "/", nome, "/", "_extensions/report/report.tex"),
      overwrite = TRUE,
      copy.mode = TRUE
     )
    file.copy(
      from = system.file("extdata/_extensions/report/logo_pe_branco.png", package = "vialactea"),
      to = paste0(path, "/", nome, "/", "_extensions/report/logo_fundo_branco.png"),
      overwrite = TRUE,
      copy.mode = TRUE
     )
    } else {
      file.copy(
        from = system.file("extdata/_extensions/report/sepe_report.tex", package = "vialactea"),
        to = paste0(path, "/", nome, "/", "_extensions/report/report.tex"),
        overwrite = TRUE,
        copy.mode = TRUE
      )
    }


  # if(!dir.exists(paste0(path, "/scripts"))) dir.create(paste0(path, "/scripts"))
  # if(!dir.exists(paste0(path, "/references"))) dir.create(paste0(path, "/references"))
  # if(!dir.exists(paste0(path, "/data"))) dir.create(paste0(path, "/data"))
  # if(!dir.exists(paste0(path, "/legacy"))) dir.create(paste0(path, "/legacy"))
  cat("\nTudo certo.")

}


#' Efeito para as capas das seções
#' @param path escoloha noma da pasta
#' @param name nome da pasta
#' @param organization ainda nao implementado
#' @return TRUE se tudo ok
#' @export
create_talk_skeleton <- function(nome, path = ".", organization = "SEPE", ...) {

  # ensure path exists
  if(!dir.exists(paste0(path, "/", nome))) {
    dir.create(paste0(path, "/", nome), recursive = TRUE, showWarnings = FALSE)
    message("Created base folder")
    dir.create(paste0(path, "/" , nome, "/_extensions"))
    dir.create(paste0(path, "/" , nome, "/images"))
    dir.create(paste0(path, "/" , nome, "/data"))
    dir.create(paste0(path, "/" , nome, "/www"))
    message("Created '_extensions' folder")
  } else {
    stop("Directory already exists!")
  }

  #   # collect inputs and paste together as 'Parameter: Value'
  #   dots <- list(...)

  # various reading of key-value pairs for reporting
  ext_yml <- readLines(system.file(paste0("extdata/_extensions/talk/_extension.yml"), package = "vialactea"),
                       n = 3)

  ext_ver <- gsub(
    x = ext_yml[grepl(x = ext_yml, pattern = "version:")],
    pattern = "version: ",
    replacement = ""
  )

  ext_nm <- gsub(
    x = ext_yml[grepl(x = ext_yml, pattern = "title:")],
    pattern = "title: ",
    replacement = ""
  )

  # copy from internals
  file.copy(
    from = system.file(paste0("extdata/_extensions/talk"), package = "vialactea"),
    to = paste0(path, "/" , nome, "/_extensions/"),
    overwrite = TRUE,
    recursive = TRUE,
    copy.mode = TRUE
  )

  file.copy(
    from = system.file("extdata/_extensions/talk/PoorEconomics.jpg", package = "vialactea"),
    to = paste0(path, "/" , nome, "/images/PoorEconomics.jpg"),
    overwrite = TRUE,
    copy.mode = TRUE
  )
  if (organization == "Governo de Pernambuco") {
    file.copy(
      from = system.file("extdata/_extensions/talk/govpe_styles.css", package = "vialactea"),
      to = paste0(path, "/" , nome, "/_extensions/talk/styles.css"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
  }
  # file.copy(
  #   from = system.file("extdata/_extensions/fullscreen", package = "vialactea"),
  #   to = paste0(path, "/talk/_extension/"),
  #   overwrite = TRUE,
  #   recursive = TRUE,
  #   copy.mode = TRUE
  # )
  fs::file_move(
    path = paste0(path, "/" , nome, "/_extensions/talk/data"),
    new_path = paste0(path, "/" , nome, "/")
  )

  # logic check to make sure extension files were moved
  n_files <- length(dir(paste0(path, "/" , nome, "/_extensions/talk")))

  if(n_files >= 2){
    message(paste(ext_nm, "v.", ext_ver, "foi instalado no diretório \"_extensions\"."))
  } else {
    message("Aparentemente a extensão não foi encontrada.")
  }

  file.copy(
    from = system.file("extdata/_extensions/talk/skeleton.qmd", package = "vialactea"),
    to = paste0(path, "/", nome, "/", "index.qmd"),
    overwrite = TRUE,
    copy.mode = TRUE
  )

  file.copy(
    from = system.file("extdata/_extensions/talk/references.bib", package = "vialactea"),
    to = paste0(path, "/", nome, "/", "references.bib"),
    overwrite = TRUE,
    copy.mode = TRUE
  )
  if (organization == "Governo de Pernambuco") {
    file.copy(
      from = system.file("extdata/_extensions/talk/govpe_talk.tex", package = "vialactea"),
      to = paste0(path,  "/", nome, "/", "_extensions/talk/talk.tex"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
    file.copy(
      from = system.file("extdata/_extensions/talk/logo_pe_branco.png", package = "vialactea"),
      to = paste0(path, "/", nome, "/", "_extensions/talk/logo_fundo_branco.png"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
  } else {
    file.copy(
      from = system.file("extdata/_extensions/talk/sepe_talkt.tex", package = "vialactea"),
      to = paste0(path, "/", nome, "/", "_extensions/talk/talk.tex"),
      overwrite = TRUE,
      copy.mode = TRUE
    )
  }

  # if(!dir.exists(paste0(path, "/scripts"))) dir.create(paste0(path, "/scripts"))
  # if(!dir.exists(paste0(path, "/references"))) dir.create(paste0(path, "/references"))
  # if(!dir.exists(paste0(path, "/data"))) dir.create(paste0(path, "/data"))
  # if(!dir.exists(paste0(path, "/legacy"))) dir.create(paste0(path, "/legacy"))
  cat("\nTudo certo.")

}




#' Efeito para as capas das seções
#' @param cor por enquanto, preto, branco ou colorido
#' @return endereço do iframe
#' @export
particulas <- function(cor = "colorida") {
  match.arg(cor, c("preta", "branca", "colorida", "pernambuco"))

  if (cor == "colorida")
    return("_extensions/talk/particles/index.html")
  if (cor == "branca")
    return("_extensions/talk/cover_branco/index.html")
  if (cor == "preta")
    return("_extensions/talk/cover_preto/index.html")
  if (cor == "pernambuco")
    return("_extensions/talk/cover_colorido/index.html")
  # Else
  return("_extensions/talk/particles/index.html")
}
