#' Create a Data List Filter for Shiny Tables
#'
#' Generates a data list filter widget for a Shiny table with the given ID.
#'
#' @param tableId A string. The ID of the table to which the filter will be applied.
#' @param style A string. The CSS style for the filter input field. Defaults to "width: 100%; height: 28px;".
#' @return A data list filter widget to be used in a Shiny application.
#' @export
dataListFilter <- function(tableId, style = "width: 100%; height: 28px;") {
  function(values, name) {
    dataListId <- sprintf("%s-%s-list", tableId, name)
    tagList(
      tags$input(
        type = "text",
        list = dataListId,
        oninput = sprintf("Reactable.setFilter('%s', '%s', event.target.value || undefined)", tableId, name),
        "aria-label" = sprintf("Filter %s", name),
        style = style
      ),
      tags$datalist(
        id = dataListId,
        lapply(unique(values), function(value) tags$option(value = value))
      )
    )
  }
}

#' Adiciona tooltips a valores para melhorar a experiência do usuário
#'
#' Esta função aplica um tooltip a um valor especificado, melhorando a experiência do usuário ao fornecer informações adicionais de forma interativa.
#'
#' @param value Valor ao qual o tooltip será aplicado.
#' @param tooltip Texto do tooltip a ser exibido.
#' @param ... Argumentos adicionais passados para a função `tippy`.
#' @return Um elemento HTML com um tooltip aplicado.
#' @examples
#' with_tooltip("Clique aqui", "Este é um tooltip informativo")
#' @export
with_tooltip <- function(value, tooltip, theme = "translucent left-align", ...) {
  div(
    style = "text-decoration: none; cursor: help",
    tippy(value, tooltip, theme = theme, ...)
  )
}



#' Create a Simple Horizontal Bar Chart
#'
#' Generates a simple horizontal bar chart using HTML elements.
#'
#' @param label A string. The label text displayed next to the bar.
#' @param width A string. The width of the bar. Defaults to "100%".
#' @param height A string. The height of the bar. Defaults to "1rem".
#' @param fill A string. The fill color of the bar. Defaults to "#00bfc4".
#' @param background A string. The background color of the area around the bar. Defaults to NULL.
#' @param box An integer. The width of the label box in pixels.
#' @return An HTML object representing the bar chart, ready to be used in a Shiny UI.
#' @export
bar_chart <- function(label, width = "100%", height = "1rem", fill = "#00bfc4", background = NULL, box) {
  bar <- div(style = list(background = fill, width = width, height = height))
  chart <- div(style = list(flexGrow = 1, marginLeft = "0.5rem", background = background), bar)
  div(style = list(display = "flex", alignItems = "left", marginLeft = "0.5rem"),
      div(style = paste0("width: ", box, "px; text-align:right;overflow: hidden;"), label), chart)
}


#' Convert R Plots to SVG Format
#'
#' Converts R-generated plots to SVG format, allowing for fine adjustments in the result.
#'
#' @param p An R plot object to be converted.
#' @param wid Numeric. Desired width for the resulting SVG. Defaults to 10.
#' @param ht Numeric. Desired height for the resulting SVG. Defaults to 8.
#' @param scaling Numeric. Scaling factor applied to the plot. Defaults to 2.5.
#' @return An HTML object containing the SVG of the plot.
#' @export
raw_svg <- function(p, wid = 10, ht = 8, scaling = 2.5) {
  s <- svgstring(scaling = scaling, width = wid, height = ht)
  tryCatch(print(p),
           finally = dev.off()
  )
  ss <- str_replace(s(), pattern = "width='\\d*.\\d*pt' height='\\d*.\\d*pt'", replacement = "width='100%' height='100%'")
  sss <- str_replace_all(ss, pattern = "font-family:.*;", replacement = "")
  return(htmltools::HTML(sss))
}

#' Compressão de Números Grandes para Maior Legibilidade
#'
#' Formata um número (dado como string ou valor numérico) em uma representação compacta,
#' adicionando o sufixo de unidade apropriado (por exemplo, “mil”, “milhão”, “bilhão”),
#' tanto em português (“pt”) quanto em inglês (“en”).
#'
#' @param tx  Uma string ou valor numérico representando o número a ser formatado.
#'            Se for string, pode conter separadores de milhar (vírgulas) e sinal de negativo (“-”).
#' @param lang  Código de idioma para as unidades:
#'              - `"pt"`: português (padrão)
#'              - `"en"`: inglês
#' @param type  Tipo de saída desejada:
#'              - `"complete"` (padrão): retorna número + unidade, ex. `"1,2 milhões"`
#'              - `"number"`: retorna apenas a parte numérica formatada, ex. `"1,2"`
#'              - `"unit"`: retorna apenas o sufixo de unidade, ex. `"milhões"`
#'              - `"name"`: retorna o nome pluralizado da unidade, ex. `"milhões"`
#' @param digits  Número de casas decimais a serem mantidas na parte numérica (padrão 1).
#'
#' @return
#' Uma \strong{string} com o número compactado de acordo com os parâmetros.
#' Se o valor for \code{NA} ou exceder 1e15, retorna \code{"Não disponível"} ou o número original.
#'
#' @examples
#' # Português
#' comprss("1500000")           # "1,5 milhão"
#' comprss("-2500000000", lang = "pt")
#' comprss("123456", type = "number")   # "123,5"
#'
#' # Inglês
#' comprss("1500000", lang = "en")     # "1.5 million"
#' comprss("2500", lang = "en", type = "unit")  # "thousand"
#'
#' @export
comprss <- function(tx, lang = "pt", type = "complete", digits = 1, abbr = FALSE) {

  stopifnot(type %in% c("number", "unit", "complete", "name"))
  sinais <- 1 # default positive
  tx <- unlist(tx)
  if (is.character(tx)) {
    sinais <- ifelse(stringr::str_detect(tx, stringr::fixed("-")), -1, 1)
    tx <- stringr::str_remove_all(tx, "-")
  }
  if (is.numeric(tx)) {
    sinais <- sign(tx)
    tx <- abs(tx)
  }

  number <- as.numeric(gsub("\\,", "", tx))
  dem <- c(0, 1, 2, 2, 3, 3, 4, 4)
  div <- findInterval(
    number,
    c(0, 1e3, 1e6, 1.995e6, 1e9, 1.995e9, 1e12, 1.995e12)
  )

  unit <- NULL
  if (!abbr) {
    if (lang == "pt") {
      unit <-  c("", "mil", "milhão", "milhões", "bilhão", "bilhões", "trilhão", "trilhões")[div]
      unit_name <- c("", "milhares", "milhões", "milhões", "bilhões", "bilhões", "trilhões", "trilhões")[div]
      decimal <- ","
      big <- "."
    }
    if (lang == "en") {
      unit <-  c("", "thousand", "million", "millions", "billion", "billions", "trillion", "trillions")[div]
      unit_name <- c("", "thousands", "millions", "millions", "billions", "billions", "trillions", "trillions")[div]
      decimal <- "."
      big <- ","
    }

  } else {
    if (lang == "pt") {
      unit <-  c("", "mil", "mi.", "mil.", "bi.", "bi.", "tri.", "tri.")[div]
      unit_name <- c("", "milhares", "milhões", "milhões", "bilhões", "bilhões", "trilhões", "trilhões")[div]
      decimal <- ","
      big <- "."
    }
    if (lang == "en") {
      unit <-  c("", "th.", "mi.", "mi.", "bi.", "bi.", "tri.", "tri,")[div]
      unit_name <- c("", "thousands", "millions", "millions", "billions", "billions", "trillions", "trillions")[div]
      decimal <- "."
      big <- ","
    }
  }

  val = format(
    round(number / 10^(3 * (dem[div])), digits = digits),
    nsmall = digits,
    decimal.mark = decimal,
    big.mark = big)

  rst <- ifelse(number < 1e15, {
    glue::glue("{ val } { unit }")
  }, {
    number
  })

  rst <- ifelse(is.na(rst), "Não disponível", stringr::str_remove_all(rst, "^\\s*"))
  rst <- ifelse(sinais < 0, paste0("−", rst), rst)
  unit <-  ifelse(is.na(rst), "Não disponível", unit)

  if (type == "unit")
    rst <- unit
  if (type == "number")
    rst <- val
  if (type == "name")
    rst <- unit_name

  return(rst)
}


#' Encrypt Column Values in a Tibble
#'
#' Encrypts the values of a column in a tibble using the `safer` package.
#'
#' @param col A vector. The column of the tibble whose values will be encrypted.
#' @param key A list containing the private and public keys for encryption.
#' @return A vector with the encrypted values.
#' @export
encrypt_col <- function(col, key) {
  unlist(lapply(
    col,
    function(x) {
      return(safer::encrypt_string(x, key$private_key, key$public_key))
    }
  ))
}


#' Decrypt Column Values in a Tibble
#'
#' Decrypts the values of a column in a tibble using the `safer` package.
#'
#' @param col A vector. The column of the tibble whose values will be decrypted.
#' @param key A list containing the private and public keys for decryption.
#' @return A vector with the decrypted values.
#' @export
decrypt_col <- function(col, key) {
  unlist(lapply(
    col,
    function(x) {
      return(safer::decrypt_string(x, key$private_key, key$public_key))
    }
  ))
}


#' Create a Status Badge
#'
#' Generates a visual badge to represent status or categories in user interfaces.
#'
#' @param color A string. The background color of the badge. Defaults to "#aaa".
#' @param width A string. The width of the badge, defining the diameter of the circle. Defaults to "0.55rem".
#' @param height A string. The height of the badge. Defaults to the same as `width`.
#' @return An HTML object representing the status badge.
#' @export
status_badge <- function(color = "#aaa", width = "0.55rem", height = width, rad = '50%', style = "margin-right:0.5rem") {
  bdg <- htmltools::tags$span(style =
         glue::glue('display:inline-block;{ style };width:{ width };height:{ height }; background-color:{ color };border-radius:{ rad }'))
  if (interactive()) {
    htmltools::browsable(bdg)
  } else {
    return(bdg)
  }
}


#' Verify User Credentials against a PostgreSQL Database
#'
#' Checks user credentials against a PostgreSQL database using a configured connection and specific authentication criteria.
#' This function is designed to be used in conjunction with login systems in Shiny applications, enabling secure user verification.
#'
#' @param sepe_datalake A list containing database connection information (server, user, password, etc.).
#' @param seed Additional seed information, if necessary for encryption logic.
#' @param session Shiny session object, used to access specific user session data.
#' @param tablea Postgres/GreenPlum user table used
#' @return An anonymous function that accepts 'user' (username) and 'password', connects to the database, verifies the credentials,
#'   and returns a list indicating if the login was successful and additional user information.
#' @examples
#' \dontrun{
#'   # Example usage within a Shiny server function
#'   creds_checker <- check_creds(sepe_datalake, seed, session)
#'   result <- creds_checker(user = input$username, password = input$password)
#'   if (result$result) {
#'     # Handle successful login
#'   } else {
#'     # Handle failed login
#'   }
#' }
#' @export
check_creds <- function(sepe_datalake, seed, session, tabela = "app_usuarios", showbusy = FALSE) {
  message("Checando credenciais...")
  #if (showbusy) shinybusy::show_modal_spinner(spin = "semipolar") # show the spinner
  on.exit({
    message("Finalizando...")
    #shinybusy::remove_modal_spinner()
  })


  function(user, password) {
    if (is.null(user) | is.null(password)) return(list(result = FALSE))
    con_checkcred <- DBI::dbConnect(
      drv      = RPostgres::Postgres(),
      host     = sepe_datalake$server,
      user     = sepe_datalake$uid,
      password = sepe_datalake$pwd,
      port     = sepe_datalake$port,
      dbname   = sepe_datalake$database
    )

    if (sepe_datalake$uid == "simec_usr")
      dbExecute(con_checkcred, "SET search_path = sepe, public;")
    req <- glue_sql("SELECT * FROM {`tabela`} WHERE \"nome\" = ({nome}) AND \"senha\" = ({senha})",
                    tabela = tabela,
                    nome = safer::encrypt_string(user, key$private_key, key$public_key),
                    senha = safer::encrypt_string(password, key$private_key, key$public_key),
                    .con = con_checkcred
    )

    #message(req)

    res <- dbGetQuery(con_checkcred, req) %>%
      mutate(app = decrypt_col(app, keys),
             secretaria = decrypt_col(secretaria, keys))

    answer <- list(result = FALSE)
    #res %>% glimpse()

    if (nrow(res) > 0) {
      local <- res %>% slice_head(n = 1) %>% pull(secretaria)
      org <- dbGetQuery(con_checkcred,
                             glue_sql("SELECT orgao_sigla FROM unidades_gestoras WHERE ug_sigla = { local }",
                                      .con = con_checkcred)) %>%
        as_tibble() %>% pull(orgao_sigla)
      tibble(
        nome = user,
        app = app_name,
        secretaria = local,
        url_protocol = session$clientData$url_protocol,
        url_hostname = session$clientData$url_hostname,
        url_port = session$clientData$url_port,
        login_timestamp = Sys.time(),
        login_success = (nrow(res) > 0)
      ) %>%
        dbWriteTable(con_checkcred, "app_logs", ., append = TRUE)
      list_apps <- paste0(res$app, collapse = ";")
      #message(list_apps)
      if (str_detect(list_apps, app_name)) {
       answer <- list(result = TRUE, user_info = list(user = user, local = local, org = org))
      }
    }
    dbDisconnect(con_checkcred)
    return(answer)
  }
}


#' Load Spinning SVG Animation
#'
#' This function generates an HTML object containing an SVG animation of spinning elements.
#' The SVG is embedded directly within the HTML.
#'
#' @return An HTML object containing the SVG animation.
#' @examples
#' \dontrun{
#'   # Example usage in a Shiny application
#'   ui <- fluidPage(
#'     load_svg()
#'   )
#'
#'   server <- function(input, output, session) {
#'   }
#'
#'   shinyApp(ui, server)
#' }
#' @export
load_svg <- function() {
  HTML('
<svg version="1.1" id="L7" width="200" height="200" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
 <path fill="#C39BD3" d="M31.6,3.5C5.9,13.6-6.6,42.7,3.5,68.4c10.1,25.7,39.2,38.3,64.9,28.1l-3.1-7.9c-21.3,8.4-45.4-2-53.8-23.3
  c-8.4-21.3,2-45.4,23.3-53.8L31.6,3.5z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
 <path fill="#C39BD3" d="M42.3,39.6c5.7-4.3,13.9-3.1,18.1,2.7c4.3,5.7,3.1,13.9-2.7,18.1l4.1,5.5c8.8-6.5,10.6-19,4.1-27.7
  c-6.5-8.8-19-10.6-27.7-4.1L42.3,39.6z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="1s" from="0 50 50" to="-360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
 <path fill="#C39BD3" d="M82,35.7C74.1,18,53.4,10.1,35.7,18S10.1,46.6,18,64.3l7.6-3.4c-6-13.5,0-29.3,13.5-35.3s29.3,0,35.3,13.5
  L82,35.7z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
</svg>')
}

#' Create a Navbar Link with an Image
#'
#' Generates an HTML anchor (`<a>`) element containing an image, to be used as a link in a navbar.
#'
#' @param link A string. The URL that the anchor element will link to.
#' @param class A string. The CSS class to be applied to the anchor element.
#' @param image A string. The source URL of the image to be displayed within the anchor element.
#' @param width A string or numeric. The width of the image, specified as a valid CSS width value (e.g., "100px", "50%").
#' @return An HTML anchor element with an embedded image.
#' @examples
#' \dontrun{
#'   # Example usage within a Shiny UI
#'   ui <- fluidPage(
#'     fn_navbar(link = "https://www.example.com", class = "navbar-link", image = "https://www.example.com/logo.png", width = "100px")
#'   )
#'
#'   server <- function(input, output, session) {
#'   }
#'
#'   shinyApp(ui, server)
#' }
#' @export
fn_navbar <- function(link, class, image, width) {
  a(href = link,
    class = class,
    tags$img(src = image, width = width)
  )
}


#' Create a Footer Element with Custom Text
#'
#' Generates an HTML footer element containing the specified text.
#'
#' @param text A string. The text or HTML content to be included within the footer.
#' @return An HTML footer element containing the specified text.
#' @examples
#' \dontrun{
#'   # Example usage within a Shiny UI
#'   ui <- fluidPage(
#'     fn_footer(text = "<p>© 2024 My Company</p>")
#'   )
#'
#'   server <- function(input, output, session) {
#'   }
#'
#'   shinyApp(ui, server)
#' }
#' @export
fn_footer <- function(text) {
  tags$footer(
    HTML(
      text
    )
  )
}


#' Create a Reactive Trigger
#'
#' This function creates a reactive trigger that can be used to trigger reactive expressions manually in a Shiny application.
#'
#' @return A list containing two functions:
#' \describe{
#'   \item{\code{depend}}{A function to establish a reactive dependency.}
#'   \item{\code{trigger}}{A function to increment the reactive value, thus triggering the reactive dependency.}
#' }
#' @examples
#' \dontrun{
#' trigger <- makereactivetrigger()
#'
#' # Define a reactive expression that depends on the trigger
#' observe({
#'   trigger$depend()
#'   # Code that depends on the reactive trigger
#' })
#'
#' # Manually trigger the reactive expression
#' trigger$trigger()
#' }
#' @export
makereactivetrigger <- function() {
  rv <- reactiveValues(a = 0)  # Cria um objeto de valores reativos com um valor inicial de 'a' igual a 0

  # Retorna uma lista de funções para manipular o gatilho reativo
  list(
    # Função para definir uma dependência reativa
    depend = function() {
      rv$a  # Acessa o valor de 'a' para criar uma dependência reativa
      invisible()  # Retorna um valor invisível para evitar qualquer saída
    },

    # Função para acionar o gatilho reativo
    trigger = function() {
      rv$a <- isolate(rv$a + 1)  # Incrementa o valor de 'a' sem disparar reatividade
    }
  )
}


#' Função para gerar uma imagem de carregamento
#'
#' Esta função retorna um código HTML que representa uma imagem de carregamento animada.
#'
#' @return HTML Um objeto HTML que contém a imagem de carregamento animada.
#' @examples
#' loading_image()
#' @export
loadingImage <- function() {
  svg <- '<svg version="1.1" id="loadingsvg" width="100" height="100" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
 <path fill="#1F64FF" d="M31.6,3.5C5.9,13.6-6.6,42.7,3.5,68.4c10.1,25.7,39.2,38.3,64.9,28.1l-3.1-7.9c-21.3,8.4-45.4-2-53.8-23.3
  c-8.4-21.3,2-45.4,23.3-53.8L31.6,3.5z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
 <path fill="#93E600" d="M42.3,39.6c5.7-4.3,13.9-3.1,18.1,2.7c4.3,5.7,3.1,13.9-2.7,18.1l4.1,5.5c8.8-6.5,10.6-19,4.1-27.7
  c-6.5-8.8-19-10.6-27.7-4.1L42.3,39.6z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="1s" from="0 50 50" to="-360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
 <path fill="#FF6400" d="M82,35.7C74.1,18,53.4,10.1,35.7,18S10.1,46.6,18,64.3l7.6-3.4c-6-13.5,0-29.3,13.5-35.3s29.3,0,35.3,13.5
  L82,35.7z">
      <animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="2s" from="0 50 50" to="360 50 50" repeatCount="indefinite"></animateTransform>
  </path>
</svg>'
  return(HTML(svg))
}


#' Cria um badge com link
#'
#' Esta função cria um badge HTML com um link e aplica classes de status e estilo personalizável.
#'
#' @param value Texto a ser exibido no badge.
#' @param link URL para onde o badge deve redirecionar.
#' @param status Classe de status para o badge, padrão é "bg-secondary".
#' @param style Estilo CSS a ser aplicado ao badge, padrão é "padding:0 10px;".
#' @return Um elemento HTML que representa o badge com link.
#' @examples
#' tagBadge("Visite o site", "https://www.example.com")
#' @export
tagBadge <- function(value, link, status = "bg-secondary", style = "padding:0 10px;") {
  class <- glue("tag {status}", status = status)
  if (is.null(link))
    return(div(style = style, class = class, value))
  else
    return(
      a(
        style = style, href = link, target = "_blank",
        div(class = class, value)
      )
    )
}


