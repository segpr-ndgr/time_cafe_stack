#' Create a styled HTML block with a label and values
#'
#' `make_span()` generates a flexible HTML `div` containing a bold label
#' and one or more styled `span` elements for given values. NA values are
#' automatically replaced with "S/I" (Sem Informação).
#'
#' @param label Character. The text to display as a label above the values.
#' @param label_color RGB Hex color.  The text color to display as a label above the values.
#' @param value Atomic vector. One or more values to display; coerced to character.
#'   Missing values (`NA`) are shown as "S/I".
#' @param fontsize Character. CSS `font-size` for each value span (default: ".75rem").
#' @param fontsize_label Character. CSS `font-size` for the label text (default: ".75rem").
#' @param flex_value Numeric. CSS `flex` value for the container `div` (default: `1`).
#' @param class String. CSS class value for the container `span` (default: `mlk-textbox`).
#'
#' @return A `shiny.tag` object representing the styled container.
#' @importFrom shiny tags
#' @importFrom purrr map
#' @importFrom dplyr if_else
#' @export
#'
#' @examples
#' library(shiny)
#' # Single value
#' make_span("Quantidade", 123)
#'
#' # Multiple values with an NA
#' make_span("Status", c("Ativo", NA, "Pendente"), fontsize = "1rem", fontsize_label = "0.9rem")
make_span <- function(label, value,
                      label_color = "white",
                      fontsize = ".75rem",
                      fontsize_label = ".75rem",
                      flex_value = 1,
                      class = "mlk-textbox") {
  # Coerce to simple vector
  value <- unlist(value)

  # Container div with flex layout
  tags$div(
    style = paste0(
      "display: flex;",
      " flex-direction: column;",
      " row-gap: 2px;",
      " flex: ", flex_value, ";"
    ),

    # Bold label
    tags$strong(
      style = paste0("font-size: ", fontsize_label, "; color: ", label_color),
      label
    ),

    # Iterate over each value
    purrr::map(
      seq_along(value),
      ~ tags$span(class = class,
        style = paste0(
          "flex: 1; display: flex; align-items: center;",
          " padding: .375rem .75rem; font-size: ", fontsize, ";",
          " font-weight: 400; line-height: 1.25;",
          " color: var(--bs-body-color); background-clip: padding-box;",
          " border: var(--bs-border-width) solid var(--bs-border-color);",
          " border-radius: var(--bs-border-radius);",
          " transition: border-color 0.15s ease-in-out,",
          " box-shadow 0.15s ease-in-out;",
          " background-color: ghostwhite;"
        ),
        role = "textbox",
        dplyr::if_else(is.na(value[[.x]]), "S/I", as.character(value[[.x]]))
      )
    )
  )
}



#' Generate a styled value box HTML popup for a road segment
#'
#' `make_popup()` constructs a Bootstrap value box with detailed information
#' about a highway segment, including labels, SVG badges, and styled spans.
#'
#' @param ordem Numeric or character. Order index for CSS class suffix.
#' @param rodovia Character. Road name or identifier to display.
#' @param inauguracao Character or NA. Inauguration status: one of
#'   "A inaugurar", "Inaugurada", "Inaugurada Parcialmente", "Finalizada".
#'   NA yields no SVG badge.
#' @param execucao Ignored (deprecated parameter placeholder).
#' @param trecho Character or numeric. Segment length or description.
#' @param status Character. Execution status badge HTML (unused directly).
#' @param contratada Character. Name of contracted company or implementer.
#' @param municipio Character vector. Municipalities covered by the segment.
#' @param regiao_desenvolvimento Character vector. Development regions.
#' @param inicio Character or Date. Start date of execution.
#' @param fim Character or Date. End or expected completion date.
#' @param subacao Character. Sub-action identifier (unused in display).
#' @param palheta_cor Character. Palette name or identifier (unused).
#' @param cor Character. Background color for the value box (CSS color).
#' @param badge_execucao HTML string. SVG or HTML representing execution badge(s).
#' @param badge_valor HTML string. SVG or HTML representing value badge(s).
#' @param badge_status HTML string. Status badge appended in the title (unused).
#' @param badge_update HTML string. HTML text showing the last update timestamp.
#' @param badge_extensao HTML string. HTML text showing extension in KM.
#' @param revestimento HTML string.
#'
#' @return HTML content as a character string, suitable for direct rendering
#'   in Shiny UI via `HTML()`.
#'
#' @importFrom bslib value_box value_box_theme
#' @importFrom glue glue
#' @importFrom htmltools tags HTML
#' @importFrom vialactea tag_svg
#' @importFrom magrittr %>%
#' @export
#'
#' @examples
#' # Example usage in a Shiny app:
#' make_popup(
#'   ordem = 1,
#'   rodovia = "BR-101",
#'   inauguracao = "Inaugurada",
#'   execucao = NULL,
#'   trecho = "KM 0–10",
#'   status = NULL,
#'   contratada = "Empresa X",
#'   municipio = c("Recife", "Olinda"),
#'   regiao_desenvolvimento = c("RMR"),
#'   inicio = "2021-01-01",
#'   fim = "2022-12-31",
#'   subacao = NULL,
#'   palheta_cor = "default",
#'   cor = "lightblue",
#'   badge_execucao = "<span>Execução</span>",
#'   badge_valor = "<span>R$ 1M</span>",
#'   badge_status = NULL,
#'   badge_update = "Atualizado em 2025-04-20"
#' )
make_popup <- function(
    ordem, rodovia, inauguracao, execucao, trecho, status,
    contratada, municipio, regiao_desenvolvimento, inicio,
    fim, subacao, palheta_cor, cor,
    badge_execucao, badge_valor, badge_status, badge_update, badge_extensao = NULL,
    revestimento = NULL
) {
  # Rodovia label container
  valor_rodovia <- htmltools::tags$div(
    rodovia,
    style = "display: flex; flex-direction: row; align-items: center; justify-content: start;"
  )

  valor <- NULL
    # Inauguration badge via SVG
  valor <- if (!is.na(inauguracao)) {
    switch(
      inauguracao,
      "A inaugurar" = vialactea::tag_svg(
        "A inaugurar", color = "forestgreen", font = "Jost,sans-serif", fontsize = 12
      ),
      "Inaugurada" = vialactea::tag_svg(
        "Inaugurada", color = "purple", font = "Jost,sans-serif", fontsize = 12
      ),
      "Inaugurada Parcialmente" = vialactea::tag_svg(
        "Parcial", color = "purple", font = "Jost,sans-serif", fontsize = 12
      ),
      "Finalizada" = vialactea::tag_svg(
        "Finalizada", color = "black", font = "Jost,sans-serif", fontsize = 12
      ),
      ""
    )
  }

  if (!is.null(revestimento))
    valor <- tagList(valor, revestimento)

  # Compose the value box
  bslib::value_box(
    class = glue::glue("rodovias-cards card-{ordem}"),
    style = "margin:5px;",
    title = NULL,
    value = htmltools::tags$span(
      style = "align-items: center; column-gap: 10px;",
      class = "card-rodovia-value d-flex",
      valor_rodovia, valor
    ),
    # Badges for execution and value
    htmltools::tags$p(
      style = "padding-bottom:10px",
      htmltools::HTML(badge_execucao),
      htmltools::HTML(badge_valor),
      htmltools::HTML(badge_extensao)
    ),
    # Detail rows
    htmltools::tags$div(
      style = 'font-size: .75rem; display: flex; flex-direction: column; row-gap: 10px; padding-bottom:10px',
      make_span(label = "Trecho", value = trecho, class = "card-trecho-value"),
      make_span(label = "Contratada", value = contratada, class = "card-contratada-value")
    ),
    htmltools::tags$div(
      style = 'font-size: .75rem; display: flex; flex-direction: row; column-gap: 10px; align-items: stretch; padding-bottom:10px',
      make_span(label = "Municípios", value = municipio, class = "card-mun-value"),
      make_span(label = "RD", value =  regiao_desenvolvimento, class = "card-rd-value")
    ),
    htmltools::tags$div(
      style = 'font-size: .75rem; display: flex; flex-direction: row; column-gap: 10px; align-items: stretch; padding-bottom:10px',
      make_span(label = "Início", value = inicio),
      make_span(label = "Conclusão", value = fim)
    ),
    # Update timestamp
    htmltools::tags$p(
      style = "font-weight: 300; font-size: 90%;",
      htmltools::HTML(badge_update)
    ),
    full_screen = FALSE,
    theme = bslib::value_box_theme(bg = cor)
  ) %>%
    as.character() %>%
    htmltools::HTML()
}



#' Generate Colors from Numeric Scores
#'
#' `get_score_color()` normalizes a numeric vector of scores to the range [0,1]
#' and maps each value to a color gradient between light blue and dark blue.
#' Missing values (`NA`) are assigned a default gray color.
#'
#' @param score Numeric vector. Scores to convert to colors.
#'
#' @return Character vector of hex color codes corresponding to each score.
#'
#' Colors are generated by interpolating between `#9fc7df` (light blue)
#' and `#416ea4` (dark blue) using `colorRamp()`.
#'
#' @importFrom purrr map
#' @importFrom grDevices colorRamp rgb
#' @export
#'
#' @examples
#' # Single score
#' get_score_color(5)
#'
#' # Multiple scores with range
#' scores <- c(10, 20, 30, NA, 50)
#' get_score_color(scores)
get_score_color <- function(score) {
  # Normalize scores to [0,1]
  min_val <- min(score, na.rm = TRUE)
  max_val <- max(score, na.rm = TRUE)
  normalized <- (score - min_val) / (max_val - min_val)

  # Map each normalized value to a color
  result <- purrr::map_chr(
    normalized,
    function(x) {
      if (is.na(x)) {
        "#ECECEC"
      } else {
        # Interpolate between light and dark blue
        grDevices::rgb(
          grDevices::colorRamp(c("#9fc7df", "#416ea4"))(x),
          maxColorValue = 255
        )
      }
    }
  )

  result
}

# @importFrom quarto quarto_render
# @importFrom webshot2 webshot


#' Render an HTML card to PNG via Quarto and Webshot2
#'
#' `get_card_png()` creates a temporary Quarto document embedding the provided HTML `card`, renders it
#' to HTML, then captures a screenshot of the `.rodovias-cards` element as a PNG image using Webshot2.
#'
#' @param card Character. HTML string for the card to render (must include `.rodovias-cards` container).
#' @param png Character. Output file path for the resulting PNG image.
#' @param zoom Numeric. Zoom factor passed to `webshot2::webshot()` (default: 4).
#' @param expand Numeric. Expansion border in pixels for `webshot2::webshot()` (default: 5).
#' @param width Numeric. Width in pixels for the Quarto layout (default: 375).
#' @param delay Numeric. Seconds to wait before taking the screenshot (default: 0.2).
#'
#' @return Logical. `TRUE` if the PNG file was successfully created, `FALSE` otherwise.
#'
#' @importFrom readr write_lines
#' @importFrom stringr str_replace
#' @export
#'
#' @examples
#' \dontrun{
#' card_html <- "<div class='rodovias-cards'>Example</div>"
#' get_card_png(card = card_html, png = "example.png")
#' }
get_card_png <- function(card, png, zoom = 4, expand = 5, width = 375, delay = 0.2) {
  # Construct Quarto Qmd content
  code_qmd <- paste0(
    "---\n",
    "title: \"\"\n",
    "output:\n  html_document:\n    theme:\n      version: 5\n      bootswatch: pulse\n      base_font:\n        google: \"Jost\"\n---\n\n",
    "<style>\n",
    "@import url(\"https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap\");\n",
    "</style>\n\n",
    "```{css, echo=FALSE}\n",
    "body { font-family: Jost; background: transparent; }\n",
    ".value-box-area { padding: 0 !important; }\n",
    "```\n\n",
    "```{r setup, include=FALSE}\n",
    "library(readr)\n",
    "library(bslib)\n",
    "library(htmltools)\n",
    "```\n\n",
    "```{r, echo=FALSE}\n",
    "page_fillable(\n",
    "  layout_column_wrap(class = \"justify-content-center\", width = ", width, ", fixed_width = TRUE, HTML('", card, "'))\n",
    ")\n",
    "```\n"
  )

  # Write to temporary files
  temp_dir <- tempdir()
  temp_qmd <- tempfile(tmpdir = temp_dir, fileext = ".qmd")
  temp_html <- stringr::str_replace(temp_qmd, "\\.qmd$", ".html")
  readr::write_lines(code_qmd, file = temp_qmd)

  # Render Qmd to HTML and capture PNG
  quarto::quarto_render(input = temp_qmd)
  webshot2::webshot(
    url = temp_html,
    file = png,
    selector = ".rodovias-cards",
    zoom = zoom,
    expand = expand,
    delay = delay
  )

  # Return success status
  file.exists(png)
}


#' Create a Flexible Row Header for Shiny UI
#'
#' `make_row_header()` generates a horizontal flex container of header labels,
#' with customizable font size, padding, flex proportions, and text alignment.
#'
#' @param value Atomic vector. One or more header labels to display.
#' @param fontsize Character. CSS `font-size` for each header label (default: ".75rem").
#' @param cell_padding Character. CSS padding for each label cell (default: "0 1.5rem 0 0").
#' @param flex_value Numeric or numeric vector. CSS `flex` values for each label. If length differs
#'   from `value`, all labels default to `1`.
#' @param justify Character or character vector. CSS `justify-content` for each label. If length differs
#'   from `value`, all labels default to "center".
#'
#' @return A `shiny.tag` object representing a flex row of strong labels.
#'
#' @importFrom shiny tags
#' @importFrom purrr map_chr
#' @export
#'
#' @examples
#' library(shiny)
#' # Single header
#' make_row_header("Coluna 1")
#'
#' # Multiple headers with custom flex and alignment
#' make_row_header(
#'   value = c("Nome", "Idade", "Cidade"),
#'   flex_value = c(2, 1, 2),
#'   justify = c("start", "center", "end"),
#'   cell_padding = "0 1rem"
#' )
make_row_header <- function(value,
                            fontsize = ".75rem",
                            cell_padding = "0 1.5rem 0 0",
                            flex_value = 1,
                            justify = "center") {
  # Coerce to simple vector
  value <- unlist(value)
  n <- length(value)

  # Ensure vectors have proper length
  if (length(flex_value) != n) flex_value <- rep(flex_value[1], n)
  if (length(justify) != n) justify <- rep(justify[1], n)

  # Build the flex container
  tags$div(
    style = paste0(
      'display: flex; flex-direction: row;',
      ' column-gap: 2px; flex: 1;'
    ),

    # Create each header cell
    purrr::map(
      seq_len(n),
      ~ tags$strong(
        style = paste0(
          'flex: ', flex_value[[.x]], ';',
          ' display: flex; padding: ', cell_padding, ';',
          ' justify-content: ', justify[[.x]], ';',
          ' align-items: center; font-size: ', fontsize, ';'
        ),
        value[[.x]]
      )
    )
  )
}



#' Create a Flexible Data Row for Shiny UI
#'
#' `make_row()` generates a horizontal flex container of data cells,
#' with customizable font size, padding, flex proportions, and text alignment.
#' Missing values (`NA`) are replaced with "S/I".
#'
#' @param value Atomic vector. One or more cell values to display.
#' @param fontsize Character. CSS `font-size` for each cell (default: ".75rem").
#' @param cell_padding Character. CSS padding for each cell (default: ".375rem .75rem").
#' @param flex_value Numeric or numeric vector. CSS `flex` values for each cell.
#'   If length differs from `value`, all cells default to `1`.
#' @param justify Character or character vector. CSS `justify-content` for each cell.
#'   If length differs from `value`, all cells default to "left".
#'
#' @return A `shiny.tag` object representing a flex row of spans.
#'
#' @importFrom shiny tags
#' @importFrom purrr map_chr
#' @importFrom htmltools HTML
#' @importFrom dplyr if_else
#' @export
#'
#' @examples
#' library(shiny)
#' # Single row
#' make_row("Texto simples")
#'
#' # Multiple values with custom layout
#' make_row(
#'   value = c("A", "B", NA),
#'   flex_value = c(1, 2, 1),
#'   justify = c("left", "center", "right"),
#'   fontsize = "1rem"
#' )
make_row <- function(value,
                     fontsize = ".75rem",
                     cell_padding = ".375rem .75rem",
                     flex_value = 1,
                     justify = "left") {
  # Coerce to simple vector
  value <- unlist(value)
  n <- length(value)

  # Ensure vectors have correct length
  if (length(flex_value) != n) flex_value <- rep(1, n)
  if (length(justify) != n) justify <- rep(justify[1], n)

  # Build the flex container
  tags$div(
    style = paste0(
      'display: flex; flex-direction: row;',
      ' column-gap: 2px; flex: 1;'
    ),
    # Create each data cell
    purrr::map(
      seq_len(n),
      ~ tags$span(
        style = paste0(
          'flex: ', flex_value[[.x]], ';',
          ' display: flex; word-wrap: break-word;',
          ' justify-content: ', justify[[.x]], ';',
          ' align-items: center; padding: ', cell_padding, ';',
          ' font-size: ', fontsize, ';',
          ' font-weight: 400; line-height: 1.25;',
          ' color: var(--bs-body-color); background-clip: padding-box;',
          ' border: var(--bs-border-width) solid var(--bs-border-color);',
          ' border-radius: var(--bs-border-radius);',
          ' transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;',
          ' background-color: ghostwhite;'
        ),
        role = "textbox",
        htmltools::HTML(dplyr::if_else(is.na(value[[.x]]), "S/I", as.character(value[[.x]])))
      )
    )
  )
}



#' Create a City Overview Card with Road Works Details
#'
#' `make_city_card()` generates a styled Bootstrap value box presenting
#' summary information for a municipality, including population, road work
#' metrics, and detailed tables of individual works.
#'
#' @param municipio Character. Name of the municipality.
#' @param regiao_desenvolvimento Character. Development region code or name.
#' @param population Numeric. Population count for formatting.
#' @param numero_obras Integer. Number of active works in the municipality.
#' @param extensao_concluido Numeric. Total kilometers completed.
#' @param extensao_contrato Numeric. Total kilometers contracted.
#' @param valor_vigenter Deprecated (unused for display).
#' @param rodovias List or atomic vector. Names of roads under works.
#' @param trechos List or atomic vector. Corresponding segments descriptions.
#' @param contratadas List or atomic vector. Companies contracted for works.
#' @param avancos List or atomic vector. HTML snippets indicating progress badges.
#' @param badge_update HTML string. Timestamp or badge indicating last update.
#' @param badge_obras HTML string. Badge indicating number of works.
#' @param badge_valor HTML string. Badge indicating total value information.
#'
#' @return Character string of HTML, ready to render in Shiny UI via `HTML()`.
#'
#' @importFrom tibble tibble
#' @importFrom dplyr rowwise ungroup
#' @importFrom htmltools tags HTML
#' @importFrom glue glue
#' @importFrom purrr map
#' @importFrom bslib value_box value_box_theme
#' @importFrom vialactea comprss
#' @importFrom dplyr if_else
#' @export
#'
#' @examples
#' \dontrun{
#' make_city_card(
#'   municipio = "Recife",
#'   regiao_desenvolvimento = "RMR",
#'   population = 1653461,
#'   numero_obras = 3,
#'   extensao_concluido = 12.5,
#'   extensao_contrato = 15.0,
#'   valor_vigenter = NULL,
#'   rodovias = c("BR-101", "PE-015"),
#'   trechos = c("KM 0–5", "KM 5–10"),
#'   contratadas = c("Empresa A", "Empresa B"),
#'   avancos = c("<span>50%</span>", "<span>80%</span>"),
#'   badge_update = "Atualizado em 2025-04-20",
#'   badge_obras = "<span>3 obras</span>",
#'   badge_valor = "<span>R$ 10M</span>"
#' )
#' }
make_city_card <- function(
    municipio, regiao_desenvolvimento, population,
    numero_obras, extensao_concluido, extensao_contrato, valor_vigenter,
    rodovias, trechos, contratadas, avancos,
    badge_update, badge_obras, badge_valor
) {

  valor_municipio <- div(municipio, style="display: flex; flex-direction: row; align-items: center; justify-content: start;")

  #lista_obras <- tibble(rodovias = unlist(rodovias), trechos = unlist(trechos), contratadas = unlist(contratadas))
  lista_obras <- tibble(rodovias = unlist(rodovias), trechos = unlist(trechos), contratadas = unlist(contratadas), avancos = unlist(avancos)) %>%
    rowwise() %>% mutate(avancos = HTML(avancos)) %>% ungroup()


  bslib::value_box(class = glue::glue("rodovias-cards"), style = "margin:5px; position: relative;",
                   title = NULL,
                   value = tags$span(style = "align-items: center;column-gap: 10px;", class = "card-rodovia-value d-flex", valor_municipio),
                   HTML(if_else(numero_obras > 0,
                                as.character(tags$p(style = "padding-bottom:10px",
                                                    HTML(badge_obras), HTML(badge_valor)
                                )),
                                "")
                   ),
                   tags$div(style='font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px;padding-bottom:10px',
                            make_span(label = "RD", value = regiao_desenvolvimento),
                            make_span(label = "População", value = vialactea::comprss(population))
                   ),
                   HTML(if_else(numero_obras <= 0,
                                as.character(tags$p(style = "padding:10px;font-size:90%", tags$i("Sem obras contratadas pelo DER/PE"))),
                                as.character(tagList(
                                  tags$div(style='font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px; align-items: stretch;padding-bottom:10px',
                                           make_span(label = "Contratado", value = paste0(format(round(extensao_contrato, 2), decimal.mark = ",", big.mark = "."), " ㎞")),
                                           make_span(label = "Concluído", value = paste0(format(round(extensao_concluido, 2), decimal.mark = ",", big.mark = "."), " ㎞ (", format(round(100*extensao_concluido/extensao_contrato, 1), decimal.mark = ",", big.mark = "."), "%)"))
                                  ),
                                  tags$div(
                                    style = 'display: flex; flex-direction: column; align-items: stretch; row-gap: 2px;',
                                    #tags$div(style='font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px; align-items: stretch;padding-bottom:10px',
                                    make_row_header(if_else(numero_obras <= 1, list(c("Rodovia", "Trecho", "Contratada", "Avanço")), list(c("Rodovias", "Trechos", "Contratadas", "Avanços"))),
                                                    fontsize = '.5rem',
                                                    cell_padding = "0 .4rem",
                                                    flex_value = c(2, 5.5, 3.5, 1)),
                                    map(
                                      1:nrow(lista_obras),
                                      ~ make_row(lista_obras[.x,] |> as.character(),
                                                 fontsize = '.4rem',  cell_padding = ".1rem .4rem",
                                                 flex_value = c(2, 5.5, 3.5, 1),
                                                 justify = c("center", "left", "left", "right")),
                                      #flex_value = c(2, 7, 3)),
                                    )
                                    # make_row_header(if_else(numero_obras <= 1, list(c("Rodovia", "Trecho", "Contratada")), list(c("Rodovias", "Trechos", "Contratadas"))),
                                    #                   fontsize = '.5rem',
                                    #                    cell_padding = "0 .75rem",
                                    #                   flex_value = c(2, 7, 3)),
                                    #          map(
                                    #            1:nrow(lista_obras),
                                    #            ~ make_row(lista_obras[.x,] |> as.character(),
                                    #                       fontsize = '.4rem',justify = c("center", "left", "center"),
                                    #                       flex_value = c(2, 7, 3)),
                                    #          )
                                    #make_span(if_else(numero_obras <= 1, "Rodovia", "Rodovias"), rodovias, fontsize = '.4rem', fontsize_label = '.6rem', flex_value = 2),
                                    #make_span(if_else(numero_obras <= 1, "Trecho", "Trechos"), trechos, fontsize = '.4rem', fontsize_label = '.6rem', flex_value = 6),
                                    #make_span(if_else(numero_obras <= 1, "Empresa", "Empresas"), contratadas, fontsize = '.4rem', fontsize_label = '.6rem', flex_value = 4)
                                    #)
                                  )))
                   )),
                   tags$p(style = "padding:10px;font-size:50%",
                          tags$i(HTML(badge_update))
                   ),
                   tags$img(src = "/Users/leite/Github/robot/images/tree.svg",
                            style = "width:30px;height:30px;position:absolute;bottom:0px;right:40px;"),
                   tags$img(src = "/Users/leite/Github/robot/images/gov_pe3.svg",
                            style = "height:25px;position:absolute;bottom:2px;right:5px;"),
                   full_screen = FALSE,
                   theme = bslib::value_box_theme(bg = '#e9eefa')) %>%
    as.character() %>% HTML()
}



#' Create a Development Region Summary Card with Road Works Metrics
#'
#' `make_rd_card()` constructs a Bootstrap value box summarizing key indicators
#' for a development region, including population, active works counts,
#' contracted and completed extensions, monetary values, and counts of roads
#' and municipalities.
#'
#' @param regiao_desenvolvimento Character. Name or code of the development region.
#' @param population Numeric. Total population for the region (formatted with `vialactea::comprss`).
#' @param numero_obras Integer. Number of road works active in the region (badge display).
#' @param extensao_concluido Numeric. Total kilometers completed across works.
#' @param extensao_contrato Numeric. Total kilometers contracted across works.
#' @param valor_vigenter Numeric. Current total monetary value (formatted and prefixed with `R$`).
#' @param rodovias Character vector. Names of roads under work in the region.
#' @param municipios Character vector. Names of municipalities with works.
#' @param badge_update HTML string. Timestamp or badge indicating last data update.
#' @param badge_obras HTML string. Badge displaying the number of works.
#' @param badge_municipios HTML string. Badge displaying the number of municipalities.
#'
#' @return Character string of HTML representing the value box,
#'   ready to render in a Shiny UI via `HTML()`.
#'
#' @importFrom htmltools tags HTML
#' @importFrom glue glue
#' @importFrom vialactea comprss
#' @importFrom bslib value_box value_box_theme
#' @importFrom dplyr if_else
#' @export
#'
#' @examples
#' \dontrun{
#' make_rd_card(
#'   regiao_desenvolvimento = "RMR",
#'   population = 1653461,
#'   numero_obras = 5,
#'   extensao_concluido = 20.5,
#'   extensao_contrato = 25.0,
#'   valor_vigenter = 12500000,
#'   rodovias = c("BR-101", "PE-015"),
#'   municipios = c("Recife", "Olinda", "Jaboatão"),
#'   badge_update = "Atualizado em 2025-04-20",
#'   badge_obras = "<span>5 obras</span>",
#'   badge_municipios = "<span>3 municípios</span>"
#' )
#' }
make_rd_card <- function(regiao_desenvolvimento, population,
                         numero_obras, extensao_concluido, extensao_contrato, valor_vigenter,
                         rodovias, municipios, badge_update, badge_obras, badge_municipios) {

  # Region label container
  valor_regiao_desenvolvimento <- htmltools::tags$div(
    regiao_desenvolvimento,
    style = "display: flex; flex-direction: row; align-items: center; justify-content: start;"
  )

  # Build the region summary box
  bslib::value_box(
    class = glue::glue("rodovias-cards"),
    style = "margin:5px; position: relative;",
    title = NULL,
    value = htmltools::tags$span(
      style = "align-items: center;",
      class = "card-rodovia-value d-flex",
      valor_regiao_desenvolvimento
    ),
    tags$p(
      style = "padding-bottom:10px",
      htmltools::HTML(badge_obras), htmltools::HTML(badge_municipios)
    ),
    tags$div(
      style = 'font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px; padding-bottom:10px',
      make_span(label = "População", value = vialactea::comprss(population)),
      make_span(label = "Valor Vigente", value = paste0("R$ ", vialactea::comprss(valor_vigenter)))
    ),
    tags$div(
      style = 'font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px; align-items: stretch; padding-bottom:10px',
      make_span(label = "Contratado", value = paste0(format(round(extensao_contrato, 2), decimal.mark = ",", big.mark = "."), " ㎞")),
      make_span(label = "Concluído", value = paste0(
        format(round(extensao_concluido, 2), decimal.mark = ",", big.mark = "."),
        " ㎞ (", format(round(100 * extensao_concluido / extensao_contrato, 1), decimal.mark = ",", big.mark = "."), "%)"
      ))
    ),
    tags$div(
      style = 'font-size: .75rem; display:flex; flex-direction:row; column-gap: 10px; align-items: stretch; padding-bottom:10px',
      make_span(label = "Rodovias", value = rodovias, fontsize = '.6rem'),
      make_span(label = "Municípios", value = municipios, fontsize = '.6rem')
    ),
    tags$p(
      style = "font-size:50%",
      tags$i(htmltools::HTML(badge_update))
    ),
    tags$img(
      src = "/Users/leite/Github/robot/images/tree.svg",
      style = "width:30px;height:30px;position:absolute;bottom:0px;right:40px;"
    ),
    tags$img(
      src = "/Users/leite/Github/robot/images/gov_pe3.svg",
      style = "height:25px;position:absolute;bottom:2px;right:5px;"
    ),
    full_screen = FALSE,
    theme = bslib::value_box_theme(bg = '#d9ed92')
  ) %>%
    as.character() %>% htmltools::HTML()
}



#' Create a Development Region Card Listing Individual Works
#'
#' `make_rd_card_list()` constructs a Bootstrap `value_box` summarizing a development region
#' with total metrics and a detailed list of individual road works in a flex layout.
#'
#' @param regiao_desenvolvimento Character. Name or code of the development region.
#' @param numero_obras Integer. Number of active works in the region.
#' @param extensao_concluido Numeric. Total kilometers completed across works.
#' @param extensao_contrato Numeric. Total kilometers contracted across works.
#' @param valor_vigenter Numeric. Current total monetary value of works.
#' @param rodovias Character vector or list. Names of roads under works.
#' @param trechos Character vector or list. Segment descriptions for each work.
#' @param contratadas Character vector or list. Companies contracted for each work.
#' @param avancos Character vector or list. HTML badges or snippets indicating progress for each work.
#' @param badge_update HTML string. Timestamp or badge indicating last update.
#' @param badge_obras HTML string. Badge indicating the number of works.
#' @param badge_valor HTML string. Badge indicating the total value.
#'
#' @return Character string of HTML representing the value box, ready for rendering in Shiny via `HTML()`.
#'
#' @importFrom htmltools tags HTML
#' @importFrom glue glue
#' @importFrom tibble tibble
#' @importFrom dplyr rowwise ungroup if_else
#' @importFrom purrr map
#' @importFrom bslib value_box value_box_theme
#' @export
#'
#' @examples
#' \dontrun{
#' make_rd_card_list(
#'   regiao_desenvolvimento = "RMR",
#'   numero_obras = 2,
#'   extensao_concluido = 12.5,
#'   extensao_contrato = 15,
#'   valor_vigenter = 5000000,
#'   rodovias = c("BR-101", "PE-015"),
#'   trechos = c("KM 0-10", "KM 10-20"),
#'   contratadas = c("Empresa A", "Empresa B"),
#'   avancos = c("<span>80%</span>", "<span>60%</span>"),
#'   badge_update = "Atualizado em 2025-04-20",
#'   badge_obras = "<span>2 obras</span>",
#'   badge_valor = "<span>R$ 5M</span>"
#' )
#' }
make_rd_card_list <- function(regiao_desenvolvimento, numero_obras,
                              extensao_concluido, extensao_contrato, valor_vigenter,
                              rodovias, trechos, contratadas, avancos,
                              badge_update, badge_obras, badge_valor) {
  # Region header container
  valor_regiao_desenvolvimento <- htmltools::tags$div(
    regiao_desenvolvimento,
    style = "display: flex; flex-direction: row; align-items: center; justify-content: start;"
  )

  # Assemble list of works as a tibble
  lista_obras <- tibble::tibble(
    rodovias = unlist(rodovias),
    trechos = unlist(trechos),
    contratadas = unlist(contratadas),
    avancos = unlist(avancos)
  ) %>%
    dplyr::rowwise() %>%
    dplyr::mutate(avancos = htmltools::HTML(avancos)) %>%
    dplyr::ungroup()

  # Build the value box
  bslib::value_box(
    class = glue::glue("rodovias-cards"),
    style = "margin:5px; position: relative;",
    title = NULL,
    # Region header and badges
    value = htmltools::tags$span(
      style = "align-items: center;",
      class = "card-rodovia-value d-flex",
      valor_regiao_desenvolvimento
    ),
    htmltools::tags$p(
      style = "padding-bottom:10px",
      htmltools::HTML(badge_obras), htmltools::HTML(badge_valor)
    ),
    # Detailed list of works
    htmltools::tags$div(
      style = 'display: flex; flex-direction: column; align-items: stretch; row-gap: 2px;',
      make_row_header(
        dplyr::if_else(
          numero_obras <= 1,
          list(c("Rodovia", "Trecho", "Contratada", "Avanço")),
          list(c("Rodovias", "Trechos", "Contratadas", "Avanços"))
        ),
        fontsize = '.5rem',
        cell_padding = "0 .4rem",
        flex_value = c(2, 6, 3, 1)
      ),
      purrr::map(
        seq_len(nrow(lista_obras)),
        ~ make_row(
          as.character(lista_obras[.x, ]),
          fontsize = '.4rem',
          cell_padding = ".1rem .4rem",
          flex_value = c(2, 6, 3, 1),
          justify = c("center", "left", "left", "right")
        )
      )
    ),
    # Footer update badge and logos
    htmltools::tags$p(
      style = "font-size:50%; padding:10px;",
      htmltools::tags$i(htmltools::HTML(badge_update))
    ),
    htmltools::tags$img(
      src = "/Users/leite/Github/robot/images/tree.svg",
      style = "width:30px;height:30px;position:absolute;bottom:0px;right:40px;"
    ),
    htmltools::tags$img(
      src = "/Users/leite/Github/robot/images/gov_pe3.svg",
      style = "height:25px;position:absolute;bottom:2px;right:5px;"
    ),
    full_screen = FALSE,
    theme = bslib::value_box_theme(bg = '#d9ed92')
  ) %>%
    as.character() %>% htmltools::HTML()
}


#' Replace Missing or Empty Values with a Dash
#'
#' `check_nom()` ensures that `NULL`, `NA`, or empty string values
#' are replaced with an em dash (`"–"`), while preserving other values
#' as character.
#'
#' @param x Atomic vector or `NULL`. Input values to check and replace.
#'
#' @return Character vector of the same length as `x` (or
#'   length 1 if `x` is `NULL`), where any `NULL`, `NA`, or `""`
#'   entries are replaced by `"–"`, and other values are coerced to character.
#'
#' @importFrom dplyr if_else
#' @export
#'
#' @examples
#' check_nom(NULL)
#' #> "–"
#'
#' check_nom(c("Alice", NA, "", "Bob"))
#' #> c("Alice", "–", "–", "Bob")
check_nom <- function(x) {
  # Treat NULL as empty string
  if (is.null(x)) x <- ""
  # Replace NA or empty string with dash, else cast to character
  dplyr::if_else(is.na(x) | x == "", "–", as.character(x))
}


#' Generate Color Codes for Scores with Customizable Gradient
#'
#' `get_score_color()` normalizes a numeric vector of scores and maps each value
#' to a color along a gradient defined by `low_color` and `high_color`. Missing or
#' invalid scores are assigned a `base_color`.
#'
#' @param score Numeric vector. Input scores to be normalized and colored.
#' @param low_color Character. Hex code for the color corresponding to the minimum score (default: `"#9fc7df"`).
#' @param high_color Character. Hex code for the color corresponding to the maximum score (default: `"#416ea4"`).
#' @param base_color Character. Hex code for the color assigned to `NA` or non-numeric entries (default: `"#ECECEC"`).
#'
#' @return Character vector of hex color codes, one for each element in `score`.
#'
#' Colors are interpolated using `grDevices::colorRamp()` and converted to hex
#' via `grDevices::rgb()` with `maxColorValue = 255`.
#'
#' @importFrom purrr map
#' @importFrom grDevices colorRamp rgb
#' @export
#'
#' @examples
#' # Default gradient
#' get_score_color(c(10, 20, 30, NA, 50))
#'
#' # Custom gradient from green to red
#' get_score_color(
#'   score = c(5, 15, 25, 35, 45),
#'   low_color = "#00FF00",
#'   high_color = "#FF0000",
#'   base_color = "#CCCCCC"
#' )
get_score_color <- function(score,
                            low_color = "#9fc7df",
                            high_color = "#416ea4",
                            base_color = "#ECECEC") {
  # Normalize scores between 0 and 1
  min_val <- min(score, na.rm = TRUE)
  max_val <- max(score, na.rm = TRUE)
  normalized <- (score - min_val) / (max_val - min_val)

  # Map each normalized value to a color
  result <- purrr::map(
    normalized,
    function(x) {
      if (is.na(x)) {
        base_color
      } else {
        grDevices::rgb(
          grDevices::colorRamp(c(low_color, high_color))(x),
          maxColorValue = 255
        )
      }
    }
  )

  result
}


