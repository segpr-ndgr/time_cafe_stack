#' pal_validade_positiva
#'
#' Generates a color palette for positive validity values.
#'
#' @param x Numeric vector of validity values.
#' @return A vector of colors.
#' @export
pal_validade_positiva <- function(x) {
  vialactea::mapColors(
    x,
    brewerPaletteName = "Greens",
    binEnds = c(seq(from = 0, to = 90, by = 30), Inf),
    reverse = TRUE
  )
}

#' pal_validade_negativa
#'
#' Generates a color palette for negative validity values.
#'
#' @param x Numeric vector of validity values.
#' @return A vector of colors.
#' @export
pal_validade_negativa <- function(x) {
  vialactea::mapColors(
    x,
    brewerPaletteName = "YlOrRd",
    binEnds = c(seq(from = 0, to = -90, by = -30), Inf),
    reverse = FALSE
  )
}

#' pal_validade
#'
#' Generates a color based on validity value, using appropriate positive or negative palette.
#'
#' @param x A numeric value of validity.
#' @return A color code as a string.
#' @export
pal_validade <- function(x) {
  if (is.na(x)) {
    return("#808080")
  }
  if (x >= 0) {
    pal_validade_positiva(x)
  } else {
    pal_validade_negativa(x)
  }
}

#' parse_nested
#'
#' Parses a nested string and splits it by commas not inside parentheses or brackets.
#'
#' @param string A character string to parse.
#' @return A character vector of parsed elements.
#' @noRd
parse_nested <- function(string) {
  chars <- strsplit(string, "")[[1]]

  parentheses <- numeric(length(chars))
  parentheses[chars == "("] <- 1
  parentheses[chars == ")"] <- -1
  parentheses <- cumsum(parentheses)

  brackets <- numeric(length(chars))
  brackets[chars == "["] <- 1
  brackets[chars == "]"] <- -1
  brackets <- cumsum(brackets)

  split_on <- which(brackets == 0 & parentheses == 0 & chars == ",")
  split_on <- c(0, split_on, length(chars) + 1)

  result <- character()

  for (i in seq_along(head(split_on, -1))) {
    x <- paste0(chars[(split_on[i] + 1):(split_on[i + 1] - 1)], collapse = "")
    result <- c(result, x)
  }

  trimws(result)
}

#' create_buttons
#'
#' Creates a function to generate buttons for each row in a table or card.
#'
#' @param ids Vector of input IDs.
#' @param labels Optional vector of labels for the buttons.
#' @param icons Optional vector of icon names.
#' @param short_labels Optional vector of short names (abbr.).
#' @param tooltips Vector of tooltips for the buttons.
#' @param type Type of buttons, either "table" or "card".
#' @return A function that generates buttons.
#' @noRd
create_buttons <- function(ids, labels = NULL, icons = NULL, short_labels = NA_character_, tooltips, type = "table") {
  if (length(ids) != length(tooltips)) stop("Lengths must be equal")
  if (is.null(icons) & is.null(labels) & is.null(short_labels)) stop("Must provide labels, short_labels or icons")

  if (is.null(short_labels))
    short_labels <- NA_character_

  if (!is.null(icons)) {
    if (length(ids) != length(icons)) stop("Lengths must be equal")
  }
  if (!is.null(labels)) {
    if (length(ids) != length(labels)) stop("Lengths must be equal")
  }

  # if (!is.null(short_labels)) {
  #   if (length(ids) != length(short_labels)) stop("Lengths must be equal")
  # }

  class_list_btn <- class_btn <- "btn"
  if (is.null(labels)) labels <- ""

  if (type == "table") {
    class_btn <- "mlk-details-btn"
    class_list_btn <- "mlk-details-btn-list"
  }

  if (type == "card") {
    class_btn <- "mlk-card-btn"
    class_list_btn <- "mlk-card-btn-list"
  }

  df <- tibble(
    id = ids,
    icon = icons,
    tooltip = tooltips,
    label = labels,
    short_label = short_labels
  )

  buttons <- as.character(tags$div(
    class = class_list_btn,
    pmap(.l = df, .f = function(id, icon, tooltip, label, short_label) {

      if (is.na(short_label)) {
        pre_label <- fontawesome::fa(icon, a11y = "sem", title = tooltip)
      } else {
        pre_label <- short_label
      }


      tags$button(
        class = class_btn,
        onclick = paste0("mlkCardButton('", "__replace__", "', '", id, "');"),
        tooltip(
          tagList(pre_label, label),
          tooltip,
          options = list(trigger = "hover")
        )
      )
    })
  ))

  f <- function(x) as.character(map(x, ~ str_replace_all(buttons, pattern = stringr::fixed("__replace__"), replacement = x)))
  return(f)
}

#' make_card
#'
#' Generates a card UI element with given content and styling.
#'
#' @param code Code to replace in button onclick.
#' @param title Title of the card.
#' @param body Body content of the card.
#' @param card_class CSS class for the card.
#' @param header_background Background color for the card header.
#' @param header_class CSS class for the card header.
#' @param body_class CSS class for the card body.
#' @param footer_class CSS class for the card footer.
#' @param botoes Function to generate buttons.
#' @return A Shiny UI card element.
#' @export
make_card <- function(code, title, body,
                      card_class = "mlk-card",
                      header_background = "black",
                      header_class = "mlk-card-header-size",
                      body_class = "mlk-card-body-size justify-content-between",
                      footer_class = "mlk-card-footer-size",
                      botoes) {
  card(
    max_height = "50%", class = card_class,
    card_header(
      title,
      class = header_class,
      style = glue("font-weight:600;background:{ cor }", cor = header_background)
    ),
    card_body(
      class = body_class,
      body
    ),
    card_footer(
      class = footer_class,
      HTML(botoes(code))
    )
  )
}

#' get_links_header
#'
#' Generates the header links for the UI module.
#'
#' @param ns Shiny namespace function.
#' @return A Shiny UI element with header links.
#' @noRd
get_links_header <- function(ns) {
  tagList(
    div(
      actionLink(
        inputId = ns("toggle_cards_table"),
        class = "mlk-link mlk-pointer",
        style = "padding:0 5px;color:var(--bs-primary);",
        label = HTML(glue(
          "<i id='{ tb }' onclick='mlkToggle(this, \"fa-toggle-on\", \"fa-toggle-off\");' class=\"fa fa-lg fa-toggle-off\"></i>",
          tb = ns("toggle-button")
        ))
      ) %>% tooltip("Mudar para cartões", options = list(trigger = "hover")),
      actionLink(
        inputId = ns("eye_hide_columns"),
        class = "mlk-link mlk-pointer",
        style = "padding:0 5px;color:var(--bs-primary);",
        label = HTML(glue(
          "<i id='{ ns('eye-button') }' onclick='mlkToggle(this, \"fa-eye-slash\", \"fa-eye\");' class=\"fa fa-lg fa-eye\"></i>"
        ))
      ) %>% tooltip("Mostrar/Esconder colunas", options = list(trigger = "hover")),
      downloadLink(
        outputId = ns("download_selection"),
        label = HTML("<i style = \"padding:0 5px;color:var(--bs-primary);\" class=\"fa fa-lg fa-download mlk-link mlk-pointer\"></i>")
      ) %>%
        tooltip("Baixar seleção", options = list(trigger = "hover")),
      popover(
        fontawesome::fa("palette", a11y = "sem", title = "Legenda de Cores"),
        title = "Legenda de cores",
        div(
          div(vialactea::status_badge(pal_validade(-100), rad = "15%", width = "1.75rem", height = ".75rem"), "Vencido a mais de 90 dias"),
          div(vialactea::status_badge(pal_validade(-70), rad = "15%", width = "1.75rem", height = ".75rem"), "Vencido a mais de 60 dias"),
          div(vialactea::status_badge(pal_validade(-40), rad = "15%", width = "1.75rem", height = ".75rem"), "Vencido a mais de 30 dias"),
          div(vialactea::status_badge(pal_validade(-10), rad = "15%", width = "1.75rem", height = ".75rem"), "Vencido a menos de 30 dias"),
          div(vialactea::status_badge(pal_validade(10), rad = "15%", width = "1.75rem", height = ".75rem"), "Válido por até 30 dias"),
          div(vialactea::status_badge(pal_validade(40), rad = "15%", width = "1.75rem", height = ".75rem"), "Válido por até 60 dias"),
          div(vialactea::status_badge(pal_validade(70), rad = "15%", width = "1.75rem", height = ".75rem"), "Válido por até 90 dias"),
          div(vialactea::status_badge(pal_validade(100), rad = "15%", width = "1.75rem", height = ".75rem"), "Válido por mais de 90 dias")
        )
      )
    ),
    div(
      class = "align-self-end",
      tags$nav(
        tags$ul(
          class = "pagination pagination-sm", style = "margin:0",
          tags$li(
            id = "pagesize-5", class = "page-item",
            actionLink(
              ns("pagesize_5"),
              class = "page-link",
              "5"
            )
          ),
          tags$li(
            id = "pagesize-10", class = "page-item active",
            actionLink(
              ns("pagesize_10"),
              class = "page-link",
              "10"
            )
          ),
          tags$li(
            id = "pagesize-20", class = "page-item",
            actionLink(
              ns("pagesize_20"),
              class = "page-link",
              "20"
            )
          ),
          tags$li(
            id = "pagesize-50", class = "page-item",
            actionLink(
              ns("pagesize_50"),
              class = "page-link",
              "50"
            )
          ),
          tags$li(
            id = "pagesize-100", class = "page-item",
            actionLink(
              ns("pagesize_100"),
              class = "page-link",
              "100"
            )
          )
        )
      )
    )
  )
}

#' get_links_footer
#'
#' Generates the footer links for the UI module.
#'
#' @param ns Shiny namespace function.
#' @return A Shiny UI element with footer links.
#' @noRd
get_links_footer <- function(ns) {
  tagList(
    div(
      style = "flex-wrap:wrap;min-width:135px;height:24px;",
      class = "d-flex align-items-center",
      htmlOutput(ns("tbl_linhas"))
    ),
    div(
      style = "display:flex;justify-content: center;min-width: 150px;height:24px;",
      actionLink(
        ns("first_page"),
        label = tags$span(
          class = "mlk-link mlk-pointer material-symbols-outlined", "first_page",
          style = "color: var(--bs-success);"
        )
      ) %>%
        tooltip(
          "Primeira página",
          placement = "top",
          options = list(trigger = "hover")
        ),
      actionLink(
        ns("previous_page"),
        label = tags$span(
          class = "mlk-link mlk-pointer material-symbols-outlined", "chevron_left",
          style = "color: var(--bs-success);"
        )
      ) %>%
        tooltip(
          "Página anterior",
          placement = "top",
          options = list(trigger = "hover")
        ),
      htmlOutput(ns("pagination"), inline = TRUE),
      actionLink(
        ns("next_page"),
        label = tags$span(
          class = "mlk-link mlk-pointer material-symbols-outlined", "chevron_right",
          style = "color: var(--bs-success);"
        )
      ) %>%
        tooltip(
          "Página seguinte",
          placement = "top",
          options = list(trigger = "hover")
        ),
      actionLink(
        ns("last_page"),
        label = tags$span(
          class = "mlk-link mlk-pointer material-symbols-outlined", "last_page",
          style = "color: var(--bs-success);"
        )
      ) %>%
        tooltip(
          "Última página",
          placement = "top",
          options = list(trigger = "hover")
        )
    )
  )
}

#' get_canvas_helper_link
#'
#' Generates a link to open an off-canvas helper.
#'
#' @param id The target ID for the off-canvas element.
#' @param faIcon FontAwesome icon name.
#' @param title Title of the helper.
#' @param tooltip Tooltip text.
#' @return A Shiny UI element.
#' @noRd
get_canvas_helper_link <- function(id, faIcon, title, tooltip) {
  tagList(
    tags$a(
      role = "presentation",
      `aria-label` = "view icon",
      `data-bs-toggle` = "offcanvas",
      `data-bs-target` = glue("#{ id }"),
      `aria-controls` = id,
      tooltip(
        fontawesome::fa(
          faIcon,
          a11y = "sem", title = "Ajuda!"
        ),
        tooltip
      )
    ),
    get_canvas_helper(id, title)
  )
}

#' get_canvas_helper
#'
#' Generates an off-canvas helper element.
#'
#' @param target_id The ID for the off-canvas element.
#' @param title Title of the helper.
#' @return A Shiny UI element.
#' @noRd
get_canvas_helper <- function(target_id, title = "Canvas helper") {
  tags$div(
    class = "offcanvas offcanvas-start",
    `data-bs-scroll` = "true",
    tabindex = "-1",
    id = glue("{ target_id }"),
    `aria-labelledby` = glue("{ target_id }Label"),
    tags$div(
      class = "offcanvas-header",
      tags$h5(
        class = "offcanvas-title",
        id = glue("{ target_id }Label"),
        title
      ),
      tags$button(
        type = "button",
        class = "btn-close",
        `data-bs-dismiss` = "offcanvas",
        `aria-label` = "Close"
      )
    ),
    tags$div(
      class = "offcanvas-body",
      htmlOutput(outputId = glue("{ target_id }_contents"))
    )
  )
}

#' get_table
#'
#' Generates a reactable table with given data and columns.
#'
#' @param pagina_tabela Data frame to display.
#' @param column_list List of column definitions for reactable.
#' @param ns Shiny namespace function.
#' @param table_height table height
#' @return A reactable table object.
#' @noRd
get_table <- function(pagina_tabela, column_list, ns, table_height = 400) {
  reactable(
    pagina_tabela,
    pagination = FALSE,
    showSortable = FALSE,
    height = table_height,
    searchable = FALSE,
    resizable = TRUE,
    sortable = FALSE,
    filterable = FALSE,
    fullWidth = TRUE,
    class = "mlk-table",
    highlight = TRUE,
    striped = TRUE,
    defaultColDef = colDef(
      headerStyle = list(display = "flex", justifyContent = "center", alignItems = "center"),
      headerClass = "rt-align-center",
      align = "center",
      headerVAlign = "center",
      style = list(fontSize = ".75rem")
    ),
    language = br_react,
    theme = reactableTheme(
      highlightColor = "#E5F0FF",
      cellStyle = list(display = "flex", flexDirection = "column", justifyContent = "center")
    ),
    columns = column_list,
    onClick = JS(sprintf(
      "function(rowInfo, column) {
        if (column.id !== 'v1') {
          return
        }
        if (window.Shiny) {
          Shiny.setInputValue('%s', { index: rowInfo.index + 1 }, { priority: 'event' })
        }
      }",
      ns("open_details")
    ))
  )
}




#' rectable_db_ui
#'
#' @description
#' A Shiny module UI function for displaying data in a reactable table or cards,
#' with pagination and other features.
#'
#' @param id Module ID.
#' @param title Title of the card.
#' @param background_color Background color for the card header.
#' @param foreground_color Foreground (text) color for the card header.
#' @param spin_color Color for the spinner.
#'
#' @return A Shiny UI element.
#' @export
rectable_db_ui <- function(id, title, background_color,
                           foreground_color,
                           spin_color = "purple") {
  ns <- NS(id)
  tagList(
    card(style = "width: 97.5%;", class = "p-0",
         card_header(title,
                     div(
                       style = "margin-left:10px;",
                       get_canvas_helper_link(ns("canvas_output"), "circle-question", title = "Helper", tooltip = "Ajuda")
                     ),
                     class = "d-flex justify-content-center",
                     style = paste0(
                       "background-color: ", background_color, ";",
                       "color: ", foreground_color
                     )
         ),
         card_body(class = "p-0",
                   card(
                     style = "border:none;min-width:350px;margin: 0 !important;",
                     card_header(
                       style = "background:white;padding-left:5px;padding-right:5px;",
                       class = "d-flex justify-content-between align-items-center",
                       get_links_header(ns)
                     ),
                     card_body(fillable = TRUE,
                               class = "p-0",
                               fill = TRUE,
                               htmlOutput(outputId = ns("cards_or_table")) %>%
                                 shinycssloaders::withSpinner(type = 8, size = .5,
                                                              color = spin_color)
                     ),
                     card_footer(
                       style = "background:white;",
                       class = "p-0 d-flex justify-content-between align-items-end",
                       get_links_footer(ns)
                     )
                   )
         ))
  )
}

#' rectable_db_server
#'
#' @description
#' A Shiny module server function for displaying data in a reactable table or cards,
#' with pagination and other features.
#'
#' @param id Module ID.
#' @param data_tbl Data table to display.
#' @param ns_parent Namespace of the parent module.
#' @param column_list List of columns for the reactable.
#' @param config_eye Configuration for hiding/showing columns.
#' @param buttons_list List of buttons to include. Default is NULL.
#' @param format_cards Function to format the cards.
#'
#' @return A Shiny server module.
#' @export
rectable_db_server <- function(id, dados, ns_parent, column_list, config_eye, buttons_list = NULL, format_cards) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns


      # Visualization type
      output$cards_or_table <- renderUI({
        condition <- FALSE
        if (!is.null(input$toggle_card)) condition <- input$toggle_card
        if (condition) {
          return(htmlOutput(outputId = ns("cards_output")) %>%
                   shinycssloaders::withSpinner(type = 8, size = .5,
                                                color = "purple"))
        } else {
          return(reactableOutput(ns("table_output")) %>%
                   shinycssloaders::withSpinner(type = 8, size = .5,
                                                color = "purple"))
        }
      })

      output$pagination <- renderUI({
        #message("Atualizando linhas")
        req(dados$total, dados$limit, dados$offset)
        if (dados$total > 0) {
          return(tags$span(
            paste0(format(1 + ceiling(dados$offset / dados$limit),
                          decimal.mark = ",", big.mark = "."),
                   " de ", format(ceiling(dados$total / dados$limit),
                                  decimal.mark = ",", big.mark = ".")),
            style = "padding: 0; font-size: 80%"
          ))
        } else {
          return("Sem dados.")
        }
      })

      output$tbl_linhas <- renderUI({
        #message("Atualizando linhas")
        req(dados$total, dados$limit, dados$offset)
        if (dados$total > 0) {
          return(tags$span(
            style = "padding: 0 8px; font-size: 80%; min-width:125px;",
            paste0(
              format(1 + dados$offset, decimal.mark = ",", big.mark = "."),
              " a ",
              format(min(dados$offset + dados$limit, dados$total), decimal.mark = ",", big.mark = "."),
              " de ",
              format(dados$total, decimal.mark = ",", big.mark = ".")
            )
          ))
        } else {
          return("Sem dados.")
        }
      })

      # Page size observers
      observeEvent(input$pagesize_5, {
        req(dados$tabela)
        dados$limit <- 5L
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
        shinyjs::addClass(id = "pagesize-5", class = "active", asis = TRUE)
        map(paste0("pagesize-", c(10, 20, 50, 100)), ~ shinyjs::removeClass(id = .x, class = "active", asis = TRUE))
      })

      observeEvent(input$pagesize_10, {
        req(dados$tabela)
        dados$limit <- 10L
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
        shinyjs::addClass(id = "pagesize-10", class = "active", asis = TRUE)
        map(paste0("pagesize-", c(5, 20, 50, 100)), ~ shinyjs::removeClass(id = .x, class = "active", asis = TRUE))
      })

      observeEvent(input$pagesize_20, {
        req(dados$tabela)
        dados$limit <- 20L
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
        shinyjs::addClass(id = "pagesize-20", class = "active", asis = TRUE)
        map(paste0("pagesize-", c(5, 10, 50, 100)), ~ shinyjs::removeClass(id = .x, class = "active", asis = TRUE))
      })

      observeEvent(input$pagesize_50, {
        req(dados$tabela)
        dados$limit <- 50L
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
        shinyjs::addClass(id = "pagesize-50", class = "active", asis = TRUE)
        map(paste0("pagesize-", c(5, 10, 20, 100)), ~ shinyjs::removeClass(id = .x, class = "active", asis = TRUE))
      })

      observeEvent(input$pagesize_100, {
        req(dados$tabela)
        dados$limit <- 100L
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
        shinyjs::addClass(id = "pagesize-100", class = "active", asis = TRUE)
        map(paste0("pagesize-", c(5, 10, 20, 50)), ~ shinyjs::removeClass(id = .x, class = "active", asis = TRUE))
      })

      # Pagination observers
      observeEvent(input$first_page, {
        req(dados$limit, dados$tabela)
        dados$offset <- 0
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$limit, order_by = row)
      })

      observeEvent(input$previous_page, {
        req(dados$offset, dados$limit, dados$tabela)
        dados$offset <- max(dados$offset - dados$limit, 0, na.rm = TRUE)
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$offset + dados$limit, order_by = row) %>%
          compute() %>%
          slice_max(n = dados$limit, order_by = row)
      })

      observeEvent(input$next_page, {
        req(dados$offset, dados$limit, dados$total, dados$tabela)
        dados$offset <- min(dados$offset + dados$limit, (floor(dados$total / dados$limit)) * dados$limit, na.rm = TRUE)
        limit <- if ((dados$offset + dados$limit) > dados$total) {
          dados$total - dados$offset
        } else {
          dados$limit
        }
        dados$pagina <- dados$tabela %>%
          slice_min(n = dados$offset + limit, order_by = row) %>%
          compute() %>%
          slice_max(n = limit, order_by = row)
      })

      observeEvent(input$last_page, {
        req(dados$limit, dados$total, dados$tabela)
        dados$offset <- (floor((dados$total - 1) / dados$limit)) * dados$limit
        limit <- if ((dados$offset + dados$limit) > dados$total) {
          dados$total - dados$offset
        } else {
          dados$limit
        }
        dados$pagina <- dados$tabela %>%
          slice_max(n = limit, order_by = row)
      })

      # Download handler
      output$download_selection <- downloadHandler(
        filename = function() {
          showNotification("Preparando dados para download...", duration = 2)
          "contratos.xlsx"
        },
        content = function(file) {
          dados$tabela %>%
            select(-row) %>%
            collect() %>%
            write_xlsx(path = file)
        }
      )

      # Toggle cards/table
      observeEvent(input$toggle_cards_table, {
        session$sendCustomMessage(
          type = 'switch-card-table',
          message = list(
            card_id = ns("toggle_card"),
            toggle_card_id = ns('toggle-button'),
            eye = ns('eye-button'),
            cols = config_eye$cols,
            cols_never = config_eye$never,
            id = ns("table_output"),
            input_id = ns("toggle_columns")
          )
        )
      })

      # Hide/show columns
      observeEvent(input$eye_hide_columns, {
        req(input$eye_hide_columns)
        session$sendCustomMessage(
          type = 'show-hide-values',
          message = list(
            cols = config_eye$cols,
            cols_never = config_eye$never,
            id = ns("table_output"),
            input_id = ns("toggle_columns")
          )
        )
      })

      # Reactable table output
      gen_buttons_table <- create_buttons(ids = ns_parent(buttons_list$ids),
                                          icons = buttons_list$icons,
                                          short_labels = buttons_list$short_labels,
                                          tooltips = buttons_list$tooltips)


      output$table_output <- renderReactable({
        req(dados$pagina)

        base <- dados$pagina %>% arrange(row) %>%
          collect() %>%
          select(-row)

        base$Code_Input <- base[[buttons_list$codigo]]
        pagina_tabela <- base %>%
          rowwise() %>%
          mutate(detalhes = gen_buttons_table(Code_Input)) %>%
          select(-Code_Input) %>%
          select(detalhes, everything())

        get_table(pagina_tabela = pagina_tabela, column_list = column_list, ns = ns)
      })

      # Cards output
      gen_btns_cards <- create_buttons(ids = ns_parent(buttons_list$ids),
                                       labels = buttons_list$labels,
                                       icons = buttons_list$icons,
                                       tooltips = buttons_list$tooltips,
                                       type = "card")

      output$cards_output <- renderUI({
        flag_columns <- input$toggle_columns
        if (is.null(flag_columns)) {
          flag_columns <- "hide"
        }

        format_cards(dados$pagina, flag_columns, gen_btns_cards)
      })
    }
  )
}
