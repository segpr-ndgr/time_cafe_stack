
pe_palheta_1 <- function(tipo = 1) {

  palette_pe <- c(
    "#4400FF", # Blue / Cold
    "#0068FF",
    "#00B7FF",
    "#3AE8C6",
    "#4AE23D",
    "#97E53C",
    "#FFCE00",
    "#FFB000",
    "#FF6700",
    "#ED282C"  # Red / Hot
  )

  palette_pe_2 <- c(
    "#4400FF", # Blue / Cold
    "#1F64FF",
    "#14B6FF",
    "#35E9C3",
    "#42E300",
    "#93E600",
    "#FDCE00",
    "#FDAF00",
    "#FF6400",
    "#EC1C23") # Red / Hot

  if (tipo == 1) return(palette_pe_1)
  if (tipo == 2) return(palette_pe_2)

  main_color_pe_1 <- "#0C2856"
  main_color_pe_2 <- "#4400FF"

  if (tipo == 3) return(main_color_pe_1)
  if (tipo == 4) return(main_color_pe_2)

  return(NA_character_)

}
