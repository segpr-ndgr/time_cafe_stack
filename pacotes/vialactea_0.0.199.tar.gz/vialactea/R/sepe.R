#' Emphasize a sentence making in bold and colorized
#'
#' @param x text to make bold
#' @param color color of the text
#' @return html code with strong tag and color in style
#' @export
stcol <- function(x, color = "#153989", ontouchend="") { ##3c763d
  paste0("<strong ontouchend='", ontouchend,  "' style='color:",color,"'>",x,"</strong>")
}

#' Emphasize a sentence making in bold and colorized, detect if output is latex or html
#'
#' @param x text to make bold
#' @param color color of the text
#' @param strong default false, true to make it bold
#' @return html code with strong tag and color in style
#' @export
colorize <- function(x, color, strong = FALSE) {
  if (knitr::is_latex_output()) {
    if (strong){
      sprintf("\\textbf{\\textcolor{%s}{%s}}", color, x)
    } else {
      sprintf("\\textcolor{%s}{%s}", color, x)
    }
  } else if (knitr::is_html_output()) {
    if (strong){
      sprintf("<strong style='color: %s;'>%s</strong>", color, x)
    } else {
      sprintf("<span style='color: %s;'>%s</span>", color, x)
    }
  } else x
}

#' Stand out style for author name
#'
#' @param x Quote's author name
#' @param color color of the text
#' @param class class to add when html output
#' @param ontouchend to the future
#' @return author name with style
#' @export
quoteauthor <- function(x, class="quoteauthor", color = "black", ontouchend="") {
  if (knitr::is_latex_output()) {
    sprintf("\\begin{flushright}
              --- \\textbf{\\textcolor{%s}{%s}}
              \\end{flushright} ", color, x)
  } else if (knitr::is_html_output()) {
    paste0("<br><footer style='color:",color, "' class='",
           class, "' ontouchend='",
           ontouchend, "'> ---", x,"</span>")
  } else x
}



#' format date
#'
#' @return date in long format (pt-BR)
#' @export
data_long_br <- function() {
  paste0(as.numeric(format(Sys.Date(), "%d")), " de ", readr::date_names_lang("pt")$mon[as.numeric(format(Sys.Date(), "%m"))], " de ",
         as.numeric(format(Sys.Date(), "%Y")))
}

# # format numbers
# # @param tx number to adjust
# # @return fomated number
# # @export
# comprss <- function(tx) {
#   div <- findInterval(as.numeric(gsub("\\,", "", tx)),
#                       c(0, 1e3, 1e6, 2e6, 1e9, 2e9, 1e12, 2e12) )
#   # modify this if negative numbers are possible
#   dem = c(0, 1, 2, 2, 3, 3, 4)
#   paste(format(round(as.numeric(gsub("\\,","",tx))/10^(3*(dem[div])), 2),
#                decimal.mark = ",", big.mark = "."),
#         c("","mil","milhão", "milhões","bilhão","bilhões","trilhão", "trilhões")[div] )
# }


##### NEET TO MOVE TO VIALACTEA.EXTRA
#' Efeito para as capas das seções
#' @param cor por enquanto, preto, branco ou colorido
#' @return endereço do iframe
#' @export
particulas <- function(cor = "colorida") {
  match.arg(cor, c("preta", "branca", "colorida", "pernambuco"))

 if (cor == "colorida")
   return("_extensions/talk/particles/index.html")
 if (cor == "branca")
   return("_extensions/talk/cover_branco/index.html")
  if (cor == "preta")
    return("_extensions/talk/cover_preto/index.html")
  if (cor == "pernambuco")
    return("_extensions/talk/cover_colorido/index.html")
 # Else
  return("_extensions/talk/particles/index.html")
}
