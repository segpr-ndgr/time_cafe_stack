#' Maps values into labeled bins
#' from jefferys/FusionExpressionPlot
#' by Stuart R. Jefferys
#' Basically this is a convenience wrapper around \code{\link{cut}}.
#'
#' Maps labels to a vector of numeric data based on a vector of bin ends. Each
#' label corresponds to one of n bins defined by n+1 bin boundaries (including
#' start and end boundaries, probably \code{-Inf} and \code{Inf}). It is an
#' error if the number of bins and the number of labels differ. Returns a vector
#' of the same length as data, but with each value replaced by the binLabel for
#' the bin it was sorted into. E.g if the bin labels are categories like "low",
#' "medium" and "high", this converts data to categories. Values equal to bin
#' boundaries are put in the lower bin, with the lowest bin boundary also
#' included in the lowest bin. Note, bin ends are always sorted from lowest to
#' highest. If you want the labels in the other order, just reverse the labels
#' vector.
#'
#' @param data A vector of numeric data to bin. Where values are \code{NA},
#'   above the highest bin end, or below the lowest they convert to \code{NA} in
#'   the returned label vector.
#'
#' @param binEnds The n+1 ends of the n bins into which the data is sorted. One
#'   bin might be \code{c(-Inf, Inf)}. Two bins equally weighted would be
#'   \code{c(-Inf, median(data), Inf)}. This vector will be sorted before
#'   assigning labels, so reverse the label order instead of providing bins as
#'   high to low. Data exactly matching bin ends will be in the lower bin, with
#'   the lowest bin end also part of the lowest bin. It is an error if any bin
#'   end is repeated.
#'
#' @param binLabels The vector of names corresponding to the labels of the bin a
#'   value belongs in.
#'
#' @return The vector of bin labels corresponding to the bins the data was
#'   sorted into.
#'
#' @section Errors:
#'    \describe{
#'       \item{
#'          \code{'breaks' are not unique}
#'       }{
#'          It is an error if any bin end is repeated.
#'       }
#'    \item{
#'       \code{lengths of 'breaks' and 'labels' differ}
#'    }{
#'       It is an error if the number of labels differs from the number of
#'       bins, or equivalently is not one less than the number of bin ends.
#'    }
#' }
#'
#' @seealso
#'    \code{\link{cut}}
#'
#' @examples
#' ends = c(Inf,-Inf,1,-1)    # Sorted to c(-Inf, -1, 1, Inf)
#' labels = c('-', '0', '+' )
#' mapLabels( c(-Inf,-5,-1,-0.5,0,0.5,1,5,Inf), ends, labels)
#' #=> [1] "-", "-", "-", "0", "0", "0", "0", "+", "+"
#'
#' ends = c(-10, 0, 10)
#' labels = c('-', '+')
#' mapLabels( c(-20, -10, -5, 0, NA, 5.2, 10, Inf), ends, labels)
#' #=> [1] NA  "-" "-" "-" NA  "+" "+" NA
#'
#' @export
mapLabels <- function(data, binEnds, binLabels) {
  if (length(binLabels) != length(binEnds) -1 ) {
    stop("lengths of 'breaks' and 'labels' differ")
  }
  bins = cut( data, binEnds, labels = 1:( length(binEnds) - 1 ), include.lowest = TRUE );
  return( binLabels[ as.numeric( levels(bins)[bins] )]);
}

#' Map colors to values
#' from jefferys/FusionExpressionPlot
#' by Stuart R. Jefferys
#' Maps colors to a vector of numeric data based on a palette of colors and a
#' vector of bin ends. Can use either a named palette from the
#' \pkg{RColorBrewer} package or a list of explicit colors. Data is binned and
#' labeled with the associated color as per \code{\link{mapLabels}}. This is not
#' intended to produce a smooth gradient, but instead compresses the information
#' in the data into a discrete set of colors.
#'
#' This is really just a convenience function to allow using color brewer
#' palettes easily when binning data. Colors are no different than other labels
#' and can be applied generically using \code{\link{mapLabels}}. Note, this
#' requires the \pkg{RColorBrewer} package if using \code{brewerPaletteName}
#'
#' @section Color Brewer Palettes:
#'
#'   If no colors are specified, a vector of colors will be assigned using the
#'   brewer palette named, \code{'RdBu'} if not specified. Each palette comes
#'   in multiple variants with a different number of colors. The number of
#'   colors will be determined automatically from the \code{binEnds} provided.
#'   Using color brewer palettes is just a convenient shortcut to specifying a
#'   list of colors and is ignored if a vector of colors is specified. If no
#'   version of the given brewer palette has the number of levels required by
#'   the bin ends, an error will occur.
#'
#'   For diverging values, can have 3 - 11 bins, allowed values are:
#'
#'   \preformatted{BrBG PiYG PRGn PuOr RdBu RdGy RdYlBu RdYlGn Spectral}
#'
#'   For sequential values, can have 3 - 8 bins, allowed values are:
#'
#'   \preformatted{Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd
#' Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd}
#'
#'        (Note: it is Greys, not Grays)
#'
#'   For qualitative palettes, can have 3 to (n) bins where n varies by palette:
#'
#'   \preformatted{Accent (8), Dark2 (8), Paired (12), Pastel1 (9), Pastel2 (8),
#' Set1 (9), Set2 (8), Set3 (12)}
#'
#'   Note: palettes are only specified in one direction, and binEnds are always
#'   sorted from lowest to highest before using, so set reverse=TRUE if you want
#'   to reverse the color order.
#'
#' @param x The vector of numeric data to map to a color
#'
#' @param binEnds The sequence of cut-points defining the bins into which the
#'   data will be split. Each bin will correspond to a color in the color vector
#'   or palette and provides for mapping each value to a color. Values exactly
#'   matching bin ends will be in the lower bin. \code{NA}s or values outside
#'   the range will map to \code{NA}. Normally the first and last bin ends are
#'   the special values \code{Inf} and \code{-Inf}. Note: bin ends will be
#'   sorted from smallest to largest before mapping, so make sure labels are
#'   ordered to match.
#'
#' @param brewerPaletteName The name of the \pkg{RColorBrewer} palette to use
#'   for bin labels, by default \code{'RdBu'}. Setting labels causes this to be
#'   ignored.
#'
#' @param colors A vector of colors to use as bin names. The number of colors
#'   will have to be one less than the number of bin ends. If this is specified,
#'   any \code{brewerPaletteName} is ignored and the \pkg{RColorBrewer} package
#'   is not needed
#'
#' @param reverse Reverse the order of the colors. If explicitly specifying the
#'   colors though \code{colors}, one could instead just reverse them. However,
#'   when using \code{brewerPaletteName}, this is the  only way to reverse the
#'   palette order. The default value is \pkg{FALSE}.
#'
#' @return The vector of colors the data maps to.
#'
#' @seealso
#'    \code{\link{mapLabels}}
#'
#' @examples
#' library(RColorBrewer);
#'
#' ### Review from RColorBrewer
#' # Display available palettes
#' display.brewer.all()
#'
#' # Display colors in a palette
#' paletteName <- "RdBu"
#' levels <- 4
#' RColorBrewer::brewer.pal(levels, paletteName)
#'
#' ### Using mapColors
#' x <- c(-100, -1, 0, 1, 100)
#' ends <- c(-Inf,-10,10,Inf)
#'
#' # Map data to 3 colors using the default (RdBu) palette
#' mapColors( x, binEnds= ends )
#' #=> [1] "#EF8A62" "#F7F7F7" "#F7F7F7" "#F7F7F7" "#67A9CF"
#'
#' # Map data to 3 colors using the reverse of the default (RdBu) palette
#' mapColors( x, binEnds= ends, reverse= TRUE)
#' #=> [1] "#67A9CF" "#F7F7F7" "#F7F7F7" "#F7F7F7" "#EF8A62"
#'
#' # Map to a specified palette name
#' mapColors( x, binEnds= ends, brewerPaletteName= 'Set1' )
#' #=> [1] "#E41A1C" "#377EB8" "#377EB8" "#377EB8" "#4DAF4A"
#'
#' # Map data using an explicit color vector
#' colorMap <- c('red', 'violet', 'blue')
#' mapColors( x, binEnds= ends, colors= colorMap)
#' #=> [1] "red"    "violet" "violet" "violet" "blue"
#'
#' mapColors( x, binEnds= ends, colors= colorMap, reverse= TRUE)
#' #=> [1] "blue"   "violet" "violet" "violet" "red"
#'
#' @export
mapColors <- function(
    x, binEnds, brewerPaletteName= 'RdBu', reverse=FALSE, colors=NULL
) {
  if (! is.null(colors)) {
    labels <- colors
  } else {
    labels= RColorBrewer::brewer.pal( length(binEnds) - 1, brewerPaletteName)
  }

  if (reverse) {
    labels <- rev(labels)
  }

  labelCol <- mapLabels( x, binEnds, labels);
  return(labelCol);
}


#' Verifica se uma cor é clara
#'
#' Converte uma cor (nomeada ou hexadecimal) para seus valores RGB e calcula a luminância relativa
#' usando a fórmula padrão. Se a luminância for maior que 128 (em uma escala de 0 a 255), a cor é considerada clara.
#'
#' @param color Character. A cor a ser avaliada. Pode ser um nome de cor (ex.: `"white"`) ou um valor hexadecimal (ex.: `"#ffffff"`).
#'
#' @return Logical. Retorna `TRUE` se a cor for considerada clara (luminância > 128) e `FALSE` caso contrário.
#'
#' @examples
#' is_light_color("white")    # retorna TRUE
#' is_light_color("#fff")      # retorna TRUE
#' is_light_color("black")    # retorna FALSE
#' is_light_color("#386391")  # normalmente retorna FALSE
#'
#' @export
is_light_color <- function(color) {
  # If the input appears to be a CSS gradient, extract the first valid color stop.
  if (grepl("gradient\\(", color, ignore.case = TRUE)) {
    color <- stringr::str_replace_all(color, "to top", "0deg")
    color <- stringr::str_replace_all(color, "to bottom.", "180deg")
    color <- stringr::str_replace_all(color, "to left.", "270deg")
    color <- stringr::str_replace_all(color, "to right.", "90deg")

    # Remove everything up to and including the first "("
    col_tmp <- sub(".*?\\(", "", color)
    # Extract the first valid color (rgba(), hex, or a word)
    first_color <- regmatches(col_tmp,
                              regexpr("(rgba?\\([^)]+\\)|#[A-Fa-f0-9]{3,6}|\\b[a-zA-Z]+\\b)",
                                      col_tmp, perl = TRUE))
    if (length(first_color) > 0 && nzchar(first_color)) {
      color <- first_color
    } else {
      color <- "gray"  # Fallback color
    }
  }
  # If the color is in the rgba format, convert it to a hexadecimal string.
  if (grepl("^rgba\\(", color, ignore.case = TRUE)) {
    # Extract numeric values from the rgba string.
    nums <- as.numeric(regmatches(color, gregexpr("\\d+\\.?\\d*", color))[[1]])
    # Convert to hex (ignoring the alpha channel in the hex conversion)
    color <- rgb(nums[1], nums[2], nums[3], maxColorValue = 255)
  }
  rgb_vals <- grDevices::col2rgb(color)
  brightness <- (rgb_vals[1,] * 299 + rgb_vals[2,] * 587 + rgb_vals[3,] * 114) / 1000
  return(brightness > 128)
}


#' Generate an SVG Badge
#'
#' Creates an SVG badge with a label and a value. The function uses [gdtools::str_metrics()]
#' to calculate the dimensions of the texts and allows dynamic styling adjustments such as
#' font size, horizontal padding, shadow effect, and corner rounding. If a CSS gradient is provided
#' as the background color, an intermediate color is extracted for brightness calculations and the gradient
#' is converted to an SVG gradient using [css_gradient_to_svg()].
#'
#' @param label Character. The label text to be displayed on the badge.
#' @param value Character. The value text to be displayed on the badge.
#' @param color Character. The background color for the value part. Can be any color recognized
#' by R (e.g., "#4c1", "red", etc) or a CSS gradient definition.
#' @param font Character. The font family used for the texts. Default is "Jost".
#' @param style Character. CSS styles applied to the SVG. Default is "margin:2px;".
#' @param fontsize Numeric. The font size (in points) used for the texts. Default is 11.
#' @param horiz_padding Numeric. Horizontal padding (in pixels) applied to the texts to define the width
#' of the background rectangles. Default is 5.
#' @param extra_right_pad Numeric. Horizontal padding (in pixels) applied to the right text to define the width
#' of the background rectangles. Default is 5.
#' @param class Character. A CSS class to be applied to the SVG. Default is "".
#' @param shadow_offset Numeric. The offset (in pixels) for the text shadow effect. Default is 2.
#' @param corner_radius Numeric. The radius for rounding the corners of the rectangle (applied to the `rx`
#' attribute). Default is 3.
#' @param icon_list Logical. If TRUE, returns a list containing the SVG, its width, and its height; otherwise,
#' @param height Numeric. badge height. Default NULL for auto calculation.
#' returns only the HTML object. Default is FALSE.
#'
#' @return An HTML object containing the SVG badge.
#'
#' @examples
#' \dontrun{
#'   library(htmltools)
#'   # Simple example using a solid color:
#'   badge <- badge_svg("Status", "Running", "#4c1", font = "Arial", fontsize = 50)
#'   browsable(badge)
#'
#'   # Example with custom corner rounding:
#'   badge2 <- badge_svg("Build", "Passing", "#4c1", corner_radius = 10)
#'   browsable(badge2)
#'
#'   # Example using a CSS gradient for the value background:
#'   badge3 <- badge_svg("Rating", "85", "linear-gradient(45deg, red 0%, blue 100%)")
#'   browsable(badge3)
#' }
#'
#' @importFrom gdtools str_metrics
#' @importFrom digest digest
#' @import htmltools
#' @export
badge_svg <- function(label, value, color,
                      font = "Jost", style = "margin:2px;",
                      fontsize = 11,
                      horiz_padding = 5,
                      extra_right_pad = 2,
                      class = "",
                      shadow_offset = 2,
                      corner_radius = 3,
                      icon_list = FALSE, height = NULL) {
  # Check if required packages are installed
  if (!requireNamespace("gdtools", quietly = TRUE)) {
    stop("The 'gdtools' package is required. Install it with install.packages('gdtools').")
  }
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("The 'digest' package is required. Install it with install.packages('digest').")
  }

  # Generate a unique suffix to avoid ID conflicts
  id_suffix <- digest::digest(paste(label, value, color, runif(1)), algo = "crc32")

  # Measure text dimensions for label and value
  metrics_label <- gdtools::str_metrics(label, fontname = font, fontsize = fontsize)
  metrics_value <- gdtools::str_metrics(value, fontname = font, fontsize = fontsize)

  width_label <- as.numeric(metrics_label["width"])
  width_value <- as.numeric(metrics_value["width"])

  # Define the background rectangle widths
  left_width  <- width_label + 2 * horiz_padding
  right_width <- width_value + 2 * horiz_padding + 2*extra_right_pad
  total_width <- left_width + right_width

  # Calculate the height of each text (sum of ascent and descent) and use the maximum
  height_label <- as.numeric(metrics_label["ascent"]) + as.numeric(metrics_label["descent"])
  height_value <- as.numeric(metrics_value["ascent"]) + as.numeric(metrics_value["descent"])
  current_height <- max(height_label, height_value)

  if (!is.null(height)) {
    current_height <- max(height, current_height, na.rm = TRUE)
  }

  final_height <- current_height * 2

  # Horizontal positions to center texts in their rectangles
  left_text_x <- horiz_padding + width_label / 2
  right_text_x <- left_width + horiz_padding + extra_right_pad + width_value / 2

  # Vertical position centered in the badge
  text_y <- final_height * 0.55

  if (is_light_color(color)) {
    value_text_shadow <- "#ccc"
    value_text_main   <- "#333"
  } else {
    value_text_shadow <- "#010101"
    value_text_main   <- "#fff"
  }

  # If 'color' is a CSS gradient, convert it to an SVG gradient.
  if (grepl("gradient\\(", color, ignore.case = TRUE)) {
    grad_id <- paste0("grad_", id_suffix)
    svg_grad <- css_gradient_to_svg(color, id = grad_id)
    fill_color <- sprintf("url(#%s)", grad_id)
  } else {
    svg_grad <- ""
    fill_color <- color
  }

  # Build the SVG string.
  # The <defs> block is included only if svg_grad is not empty.
  defs_block <- if (nzchar(svg_grad)) {
    sprintf("<defs>\n%s\n</defs>", svg_grad)
  } else {
    ""
  }

  svg <- sprintf(
    '<svg class="%s" style="%s" xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" role="img" aria-label="%s: %s">
      <title>%s: %s</title>
      %s
      <linearGradient id="s%s" x2="0" y2="100%%">
        <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
        <stop offset="1" stop-opacity=".1"/>
      </linearGradient>
      <clipPath id="r%s">
        <rect width="%d" height="%d" rx="%s" fill="#fff"/>
      </clipPath>
      <g clip-path="url(#r%s)">
        <rect width="%d" height="%d" fill="#555"/>
        <rect x="%d" width="%d" height="%d" fill="%s"/>
        <rect width="%d" height="%d" fill="url(#s%s)"/>
      </g>
      <g fill="#fff" text-anchor="middle" font-family="%s" font-size="%s" dominant-baseline="middle">
        <!-- Label text shadow -->
        <text x="%.1f" y="%.1f" fill="#010101" text-rendering="geometricPrecision" alignment-baseline="middle" fill-opacity=".3">%s</text>
        <!-- Label text -->
        <text x="%.1f" y="%.1f" text-rendering="geometricPrecision" alignment-baseline="middle" fill="#fff">%s</text>
        <!-- Value text shadow -->
        <text x="%.1f" y="%.1f" text-rendering="geometricPrecision" alignment-baseline="middle" fill="%s" fill-opacity=".3">%s</text>
        <!-- Value text -->
        <text x="%.1f" y="%.1f" text-rendering="geometricPrecision" alignment-baseline="middle" fill="%s">%s</text>
      </g>
    </svg>',
    # 1-2: class and style
    class, style,
    # 3-4: overall_width and final_height
    round(total_width), round(final_height),
    # 5-6: aria-label: label and value
    label, value,
    # 7-8: title: label and value
    label, value,
    # 9: defs block (for gradient, if any)
    defs_block,
    # 10: linearGradient id suffix
    id_suffix,
    # 11: clipPath id suffix
    id_suffix,
    # 12-13: width and height of the clipPath rectangle
    round(total_width), round(final_height),
    # 14: rx using corner_radius
    as.character(corner_radius),
    # 15: clipPath reference
    id_suffix,
    # 16-17: first rectangle (background): overall_width and final_height
    round(total_width), round(final_height),
    # 18-21: second rectangle: x, width, height, and fill (solid fill, using color)
    round(left_width), round(right_width), round(final_height), fill_color,
    # 22-24: third rectangle: overall_width, final_height, and linearGradient reference
    round(total_width), round(final_height),
    id_suffix,
    # 25-26: text group: font-family and font-size
    font, as.character(fontsize),
    # 27-29: label text shadow: x, y, content
    left_text_x + shadow_offset, text_y + shadow_offset, label,
    # 30-32: label text: x, y, content
    left_text_x, text_y, label,
    # 33-36: value text shadow: x, y, fill, and content
    right_text_x + shadow_offset, text_y + shadow_offset, value_text_shadow, value,
    # 37-40: value text: x, y, fill, and content
    right_text_x, text_y, value_text_main, value
  )

  svg <- htmltools::HTML(svg)

  if (icon_list)
    return(list(svg = svg, width = round(total_width), height = round(final_height)))

  if (interactive()) {
    htmltools::browsable(svg)
  } else {
    return(svg)
  }
}


#' Generate a Stacked SVG Badge with Separated Rounded Corners and CSS Gradient Support
#'
#' Creates an SVG badge consisting of two vertically stacked rectangles. The upper rectangle (for the label)
#' has only its top (north) corners rounded, and the lower rectangle (for the value) has only its bottom (south)
#' corners rounded. Dimensions are calculated dynamically using [gdtools::str_metrics()]. A unique hash-based suffix
#' is incorporated into internal SVG IDs to avoid conflicts. If the \code{color} argument is a CSS gradient definition,
#' the function \code{css_gradient_to_svg} is used to generate the appropriate SVG gradient, and the value rectangle
#' is filled with that gradient.
#'
#' @param label Character. The label text to be displayed in the top rectangle.
#' @param value Character. The value text to be displayed in the bottom rectangle.
#' @param color Character. The background color for the bottom rectangle (value). Can be any color recognized by R
#' (e.g., "#4c1", "red", etc) or a CSS gradient definition (e.g., "linear-gradient(45deg, red 0%, blue 100%)").
#' @param font Character. The font family used for the texts. Default is "Jost".
#' @param style Character. CSS style applied to the SVG. Default is "margin:2px;".
#' @param label_fontsize Numeric. The font size (in points) used for the label text. Default is 11.
#' @param value_fontsize Numeric. The font size (in points) used for the value text. Default is 16.
#' @param horiz_padding Numeric. Horizontal padding (in pixels) applied to the texts to determine the width of each rectangle. Default is 5.
#' @param shadow_offset Numeric. The offset (in pixels) for the text shadow effect. Default is 2.
#' @param corner_radius Numeric. The radius used for rounding corners. In the top rectangle only the top corners are rounded,
#' and in the bottom rectangle only the bottom corners are rounded. Default is 3.
#' @param icon_list Logical. If TRUE, returns a list containing the SVG, its overall width, and its overall height;
#' otherwise, returns only the HTML object. Default is FALSE.
#'
#' @return An HTML object (created with [htmltools::HTML()]) containing the stacked SVG badge.
#' In interactive sessions, the badge is displayed using [htmltools::browsable()].
#'
#' @examples
#' \dontrun{
#'   library(htmltools)
#'   # Using a simple solid color:
#'   badge <- badge_svg_stacked("Status", "Running", "#4c1", font = "Arial",
#'                               label_fontsize = 11, value_fontsize = 18)
#'   browsable(badge)
#'
#'   # Using a CSS gradient:
#'   badge2 <- badge_svg_stacked("Build", "Passing", "linear-gradient(45deg, red 0%, blue 100%)", corner_radius = 10)
#'   browsable(badge2)
#' }
#'
#' @importFrom gdtools str_metrics
#' @importFrom digest digest
#' @import htmltools
#' @export
badge_svg_stacked <- function(label, value, color,
                               font = "Jost", style = "margin:2px;",
                               label_fontsize = 11, value_fontsize = 16,
                               horiz_padding = 5, shadow_offset = 2,
                               corner_radius = 3, icon_list = FALSE) {
  # Check for required packages
  if (!requireNamespace("gdtools", quietly = TRUE)) {
    stop("The 'gdtools' package is required. Install it with install.packages('gdtools').")
  }
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("The 'digest' package is required. Install it with install.packages('digest').")
  }

  # Generate a unique suffix to avoid ID conflicts
  id_suffix <- digest::digest(paste(label, value, color, runif(1)), algo = "crc32")

  # Measure text dimensions for label and value
  metrics_label <- gdtools::str_metrics(label, fontname = font, fontsize = label_fontsize)
  metrics_value <- gdtools::str_metrics(value, fontname = font, fontsize = value_fontsize)

  label_width <- as.numeric(metrics_label["width"])
  value_width <- as.numeric(metrics_value["width"])

  # Compute rectangle widths (text width + 2 * horiz_padding)
  rect_width_label <- label_width + 2 * horiz_padding
  rect_width_value <- value_width + 2 * horiz_padding
  overall_width <- max(rect_width_label, rect_width_value)

  # Compute rectangle heights as twice the measured text height (ascent + descent)
  label_text_height <- as.numeric(metrics_label["ascent"]) + as.numeric(metrics_label["descent"])
  value_text_height <- as.numeric(metrics_value["ascent"]) + as.numeric(metrics_value["descent"])
  final_height_label <- label_text_height * 2
  final_height_value <- value_text_height * 2
  overall_height <- final_height_label + final_height_value

  # Compute text center positions in each rectangle
  label_text_x <- overall_width / 2
  label_text_y <- final_height_label * 0.55
  value_text_x <- overall_width / 2
  value_text_y <- final_height_label + final_height_value * 0.55

  # Set label text colors (fixed)
  label_text_main <- "#fff"
  label_text_shadow <- "#010101"

  # Determine value text colors based on background luminance
  # is_light_color <- function(col) {
  #   rgb <- grDevices::col2rgb(col)
  #   brightness <- (rgb[1,] * 299 + rgb[2,] * 587 + rgb[3,] * 114) / 1000
  #   return(brightness > 128)
  # }



  if (is_light_color(color)) {
    value_text_main <- "#333"
    value_text_shadow <- "#ccc"
  } else {
    value_text_main <- "#fff"
    value_text_shadow <- "#010101"
  }

  # Check if 'color' is a CSS gradient definition.
  if (grepl("gradient\\(", color, ignore.case = TRUE)) {
    grad_id <- paste0("grad_", id_suffix)
    svg_grad <- css_gradient_to_svg(color, id = grad_id)
    fill_value <- sprintf("url(#%s)", grad_id)
  } else {
    fill_value <- color
    svg_grad <- ""
  }

  # Define Y positions for the bottom rectangle
  Y0 <- final_height_label      # Top of bottom rectangle
  Y1 <- overall_height          # Bottom of badge

  # Build the path for the top rectangle (label) with only top corners rounded.
  top_path <- sprintf(
    "M 0,%.1f L 0,%.1f A %.1f,%.1f 0 0 1 %.1f,0 L %.1f,0 A %.1f,%.1f 0 0 1 %.1f,%.1f L %.1f,%.1f Z",
    final_height_label,       # move to (0, final_height_label)
    corner_radius,            # line to (0, corner_radius)
    corner_radius, corner_radius,  # arc radii for top-left
    corner_radius,            # arc end x = corner_radius (y=0)
    overall_width - corner_radius, # horizontal line to (overall_width - corner_radius, 0)
    corner_radius, corner_radius,  # arc radii for top-right
    overall_width, corner_radius,  # arc end at (overall_width, corner_radius)
    overall_width, final_height_label  # line down to (overall_width, final_height_label)
  )

  # Build the path for the bottom rectangle (value) with only bottom corners rounded.
  bottom_path <- sprintf(
    "M 0,%.1f L %.1f,%.1f L %.1f,%.1f A %.1f,%.1f 0 0 1 %.1f,%.1f L %.1f,%.1f A %.1f,%.1f 0 0 1 0,%.1f L 0,%.1f Z",
    Y0,                                  # move to (0, Y0)
    overall_width, Y0,                   # horizontal line to (overall_width, Y0)
    overall_width, Y1 - corner_radius,     # vertical line to (overall_width, Y1 - corner_radius)
    corner_radius, corner_radius,          # arc radii for bottom-right
    overall_width - corner_radius, Y1,     # arc end at (overall_width - corner_radius, Y1)
    corner_radius, Y1,                     # horizontal line to (corner_radius, Y1)
    corner_radius, corner_radius,          # arc radii for bottom-left
    Y1 - corner_radius,                  # arc end at (0, Y1 - corner_radius)
    Y0                                   # vertical line back to (0, Y0)
  )

  # Build the final SVG string. If a gradient was generated, include it in a <defs> block.
  svg <- sprintf(
    '<svg style="%s" xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" role="img" aria-label="%s: %s">
       <title>%s: %s</title>
       <defs>
         %s
       </defs>
       <!-- Top rectangle (label) -->
       <path d="%s" fill="#555"/>
       <!-- Bottom rectangle (value) -->
       <path d="%s" fill="%s"/>
       <!-- Label text group -->
       <g text-anchor="middle" font-family="%s" font-size="%s" dominant-baseline="middle">
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s" fill-opacity=".3">%s</text>
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s">%s</text>
       </g>
       <!-- Value text group -->
       <g text-anchor="middle" font-family="%s" font-size="%s" dominant-baseline="middle">
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s" fill-opacity=".3">%s</text>
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s">%s</text>
       </g>
     </svg>',
    style,
    round(overall_width), round(overall_height),
    label, value,
    label, value,
    svg_grad,
    top_path,
    bottom_path, fill_value,
    font, as.character(label_fontsize),
    label_text_x + shadow_offset, label_text_y + shadow_offset, label_text_shadow, label,
    label_text_x, label_text_y, label_text_main, label,
    font, as.character(value_fontsize),
    value_text_x + shadow_offset, value_text_y + shadow_offset, value_text_shadow, value,
    value_text_x, value_text_y, value_text_main, value
  )

  svg <- htmltools::HTML(svg)

  if (icon_list)
    return(list(svg = svg, width = round(overall_width), height = round(overall_height)))

  if (interactive()) {
    htmltools::browsable(svg)
  } else {
    return(svg)
  }
}

#' Generate a Tag in SVG
#'
#' Creates an SVG badge (tag) displaying a value with a background using dimensions
#' calculated dynamically with [gdtools::str_metrics()]. To avoid ID conflicts when
#' multiple badges are displayed together, the function generates a unique hash-based
#' suffix (using the [digest](https://cran.r-project.org/package=digest) package) which
#' is incorporated into internal SVG IDs (e.g., for `<linearGradient>` and `<clipPath>`).
#'
#' @param value Character. The value displayed on the badge.
#' @param color Character. The background color of the badge. Can be any color recognized
#' by R (e.g., "#fff", "white", "#386391", etc).
#' @param style Character. CSS style applied to the SVG. Default is `"margin:2px;"`.
#' @param font Character. The font family used for the text. Default is `"Jost"`.
#' @param fontsize Numeric. The font size (in points) used for the text. Default is `11`.
#' @param horiz_padding Numeric. Horizontal padding (in pixels) applied to the text to
#' determine the width of the background rectangle. Default is `5`.
#' @param icon_list Logical. If TRUE, returns a list containing the SVG, its width, and its
#' height; otherwise, returns only the HTML object. Default is `FALSE`.
#' @param corner_radius Numeric. The radius used for rounding the corners of the badge
#' (applied to the `rx` attribute of the rectangle in the clipPath). Default is `3`.
#'
#' @return An HTML object (created with [htmltools::HTML()]) containing the SVG badge.
#' In interactive sessions, the function displays the badge using [htmltools::browsable()].
#'
#' @details
#' The function calculates the width of the value text using [gdtools::str_metrics()]
#' and then computes the total width by adding horizontal padding on both sides. The badge's
#' height is computed dynamically as twice the text height (where the text height is the sum
#' of the ascent and descent). The text is centered vertically using `dominant-baseline="middle"`.
#'
#' @examples
#' \dontrun{
#'   library(htmltools)
#'   badge <- tag_svg("Running", "#4c1", font = "Jost", fontsize = 11)
#'   browsable(badge)
#'
#'   tagList(
#'     tag_svg("No", "#4c1", font = "Jost", fontsize = 11),
#'     tag_svg("No Info", "#41c", font = "Jost", fontsize = 11),
#'     tag_svg("OK", "#c14", font = "Jost", fontsize = 11)
#'   ) |> browsable()
#' }
#'
#' @importFrom gdtools str_metrics
#' @importFrom digest digest
#' @import htmltools
#' @export
tag_svg <- function(value,
                     color,
                     font = "Jost",
                     style = "margin:2px;",
                     fontsize = 11,
                     horiz_padding = 5,
                     icon_list = FALSE,
                     corner_radius = 3) {
  # Check if required packages are installed
  if (!requireNamespace("gdtools", quietly = TRUE)) {
    stop("The 'gdtools' package is required. Install it with install.packages('gdtools').")
  }
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("The 'digest' package is required. Install it with install.packages('digest').")
  }

  # Generate a unique suffix for internal IDs
  id_suffix <- digest::digest(paste(value, color, runif(1)), algo = "crc32")

  # Measure text dimensions using gdtools::str_metrics()
  metrics_value <- gdtools::str_metrics(value, fontname = font, fontsize = fontsize)
  width_value <- as.numeric(metrics_value["width"])
  text_height <- as.numeric(metrics_value["ascent"]) + as.numeric(metrics_value["descent"])

  # Compute the final dimensions of the badge
  total_width <- width_value + 2 * horiz_padding
  final_height <- text_height * 2
  text_x <- horiz_padding + width_value / 2
  text_y <- final_height * 0.55

  # # Helper function to determine if a color is light (using luminance)
  # is_light_color <- function(color) {
  #   rgb <- grDevices::col2rgb(color)
  #   brightness <- (rgb[1,] * 299 + rgb[2,] * 587 + rgb[3,] * 114) / 1000
  #   return(brightness > 128)
  # }
  if (is_light_color(color)) {
    value_text_shadow <- "#ccc"
    value_text_main <- "#333"
  } else {
    value_text_shadow <- "#010101"
    value_text_main <- "#fff"
  }

  # Build the SVG without scale transformations or textLength attributes
  svg <- sprintf(
    '<svg style="%s" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="%d" height="%d" role="img" aria-label="%s">
       <title>%s</title>
       <linearGradient id="s%s" x2="0" y2="100%%">
         <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
         <stop offset="1" stop-opacity=".1"/>
       </linearGradient>
       <clipPath id="r%s">
         <rect width="%d" height="%d" rx="%s" fill="#fff"/>
       </clipPath>
       <g clip-path="url(#r%s)">
         <rect width="%d" height="%d" fill="%s"/>
         <rect width="%d" height="%d" fill="url(#s%s)"/>
       </g>
       <g fill="#fff" text-anchor="middle" font-family="%s" font-size="%s" dominant-baseline="middle">
         <!-- Text shadow -->
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s" fill-opacity=".3">%s</text>
         <!-- Main text -->
         <text text-rendering="geometricPrecision" alignment-baseline="middle" x="%.1f" y="%.1f" fill="%s">%s</text>
       </g>
     </svg>',
    style,                           # SVG style
    round(total_width), round(final_height), # SVG width and height
    value,                           # aria-label
    value,                           # title
    id_suffix,                       # linearGradient id suffix
    id_suffix,                       # clipPath id suffix
    round(total_width), round(final_height), # clipPath rectangle dimensions
    as.character(corner_radius),     # rx attribute for rounded corners
    id_suffix,                       # clipPath reference
    round(total_width), round(final_height), # first rectangle (background)
    color,                           # background color
    round(total_width), round(final_height), # second rectangle (gradient overlay)
    id_suffix,                       # linearGradient reference
    font, as.character(fontsize),    # text group attributes: font family and font size
    text_x, text_y, value_text_shadow, value,  # text shadow: position, fill, content
    text_x, text_y, value_text_main, value       # main text: position, fill, content
  )

  svg <- htmltools::HTML(svg)

  if (icon_list)
    return(list(svg = svg, width = round(total_width), height = round(final_height)))

  if (interactive()) {
    htmltools::browsable(svg)
  } else {
    return(svg)
  }
}


#' Convert CSS Gradient to SVG
#'
#' Converts a CSS gradient definition into an SVG gradient element. This function supports both
#' radial and linear gradients. For radial gradients, it extracts the shape, position, and color stops
#' from the CSS string and converts common CSS position keywords into SVG coordinates. For linear gradients,
#' it extracts the gradient angle and color stops to compute the corresponding SVG coordinates.
#'
#' @param css_string Character. A CSS gradient definition (e.g.,
#' "linear-gradient(45deg, red 0%, blue 100%)" or "radial-gradient(circle at center, red 0%, blue 100%)").
#' @param id Character. The ID to assign to the generated SVG gradient element. Default is "gradient".
#'
#' @return A character string containing the SVG gradient definition.
#'
#' @details
#' For radial gradients, the function detects "radial-gradient" in the CSS string and extracts
#' the gradient shape (e.g., "circle" or "ellipse") and position (e.g., "center"). CSS keywords such as
#' "top", "bottom", "left", "right", and "center" are converted into SVG coordinate values. Color stops are
#' extracted and converted into SVG `<stop>` elements with appropriate offset and stop-opacity.
#'
#' For linear gradients, the function extracts the gradient angle and color stops from the CSS string and
#' calculates the corresponding SVG coordinates using trigonometric transformations.
#'
#' @examples
#' \dontrun{
#'   # Linear gradient example:
#'   css_str1 <- "linear-gradient(45deg, red 0%, blue 100%)"
#'   svg_grad1 <- css_gradient_to_svg(css_str1, id = "myLinearGradient")
#'   cat(svg_grad1)
#'
#'   # Radial gradient example:
#'   css_str2 <- "radial-gradient(circle at center, red 0%, blue 100%)"
#'   svg_grad2 <- css_gradient_to_svg(css_str2, id = "myRadialGradient")
#'   cat(svg_grad2)
#' }
#'
#' @importFrom digest digest
#' @export
css_gradient_to_svg <- function(css_string, id = "gradient") {
  # Helper function: Converts a single CSS color stop to an SVG <stop> element.
  # 0deg equals: to top.
  # 180deg equals: to bottom.
  # 270deg equals: to left.
  # 90deg equals: to right.
  css_string <- stringr::str_replace_all(css_string, "to top", "0deg")
  css_string <- stringr::str_replace_all(css_string, "to bottom.", "180deg")
  css_string <- stringr::str_replace_all(css_string, "to left.", "270deg")
  css_string <- stringr::str_replace_all(css_string, "to right.", "90deg")

  parse_stop <- function(stop_str) {
    color_match <- regmatches(stop_str,
                              regexpr("(rgba?\\([^)]+\\)|#[a-fA-F0-9]{3,6}|[a-zA-Z]+)",
                                      stop_str, perl = TRUE))
    color <- if (length(color_match) > 0) color_match else "black"

    if (grepl("^rgba?\\(", color, ignore.case = TRUE)) {
      color_values <- as.numeric(regmatches(color, gregexpr("\\d+\\.?\\d*", color))[[1]])
      r <- color_values[1]
      g <- color_values[2]
      b <- color_values[3]
      a <- if (length(color_values) >= 4) color_values[4] else 1
      color <- rgb(r, g, b, maxColorValue = 255)
    } else if (!grepl("^#", color) && !tolower(color) %in% tolower(colors())) {
      color <- "black"
      a <- 1
    } else {
      a <- 1
    }

    offset_match <- regmatches(stop_str, regexpr("\\d+%", stop_str))
    offset <- if (length(offset_match) > 0) offset_match else "0%"
    offset_num <- as.numeric(sub("%", "", offset))
    offset_num <- max(0, min(100, offset_num))
    offset <- paste0(offset_num, "%")

    sprintf('<stop offset="%s" stop-color="%s" stop-opacity="%.2f" />', offset, color, a)
  }

  # Helper function: Extracts all stops from a CSS gradient string.
  extract_stops <- function(css_str) {
    stops_all <- regmatches(css_str,
                            gregexpr("(rgba?\\([^)]+\\)|#[a-fA-F0-9]{3,6}|[a-zA-Z]+)\\s*\\d+%?",
                                     css_str, perl = TRUE))[[1]]
    stops_all[grepl("\\d+%", stops_all)]
  }

  # Determine whether the gradient is radial.
  is_radial <- grepl("radial-gradient", css_string, ignore.case = TRUE)

  if (is_radial) {
    # Process radial gradient.
    shape_match <- regmatches(css_string,
                              regexpr("(circle|ellipse|closest-side|farthest-side|closest-corner|farthest-corner)",
                                      css_string, ignore.case = TRUE))
    shape <- if (length(shape_match) > 0) tolower(shape_match[1]) else "ellipse"

    position_match <- regmatches(css_string,
                                 regexpr("at\\s+[^,)]+", css_string, ignore.case = TRUE))
    position <- if (length(position_match) > 0)
      sub("at\\s+", "", position_match[1], ignore.case = TRUE) else "center"

    # Convert common CSS keywords into SVG coordinates.
    position <- gsub("top", "0% 0%", position)
    position <- gsub("bottom", "0% 100%", position)
    position <- gsub("left", "0% 50%", position)
    position <- gsub("right", "100% 50%", position)
    position <- gsub("center", "50% 50%", position)

    stops <- extract_stops(css_string)
    stop_tags <- lapply(stops, parse_stop)

    # Assume the position string is in "X Y" format.
    pos_parts <- unlist(strsplit(position, "\\s+"))
    cx <- if (length(pos_parts) >= 1) pos_parts[1] else "50%"
    cy <- if (length(pos_parts) >= 2) pos_parts[2] else "50%"

    # For simplicity, use a fixed radius and focal point.
    svg_gradient <- sprintf(
      '<radialGradient id="%s" cx="%s" cy="%s" r="50%%" fx="%s" fy="%s" gradientUnits="objectBoundingBox">
      %s\n</radialGradient>',
      id, cx, cy, cx, cy,
      paste(stop_tags, collapse = "\n      ")
    )

  } else {
    # Process linear gradient.
    angle_match <- regmatches(css_string,
                              regexpr("(?<=linear-gradient\\()\\d+", css_string, perl = TRUE))
    angle <- if (length(angle_match) > 0) as.numeric(angle_match) else 0

    stops <- extract_stops(css_string)
    stop_tags <- lapply(stops, parse_stop)

    angle_rad <- (90 - angle) * pi / 180
    x1 <- round(50 * (1 - cos(angle_rad)), 2)
    x2 <- round(50 * (1 + cos(angle_rad)), 2)
    y1 <- round(50 * (1 - sin(angle_rad)), 2)
    y2 <- round(50 * (1 + sin(angle_rad)), 2)

    svg_gradient <- sprintf(
      '<linearGradient id="%s" x1="%s%%" y1="%s%%" x2="%s%%" y2="%s%%">
      %s\n</linearGradient>',
      id, x1, y1, x2, y2,
      paste(stop_tags, collapse = "\n      ")
    )
  }

  return(svg_gradient)
}

#' Generate an Interactive Donut Chart in HTML
#'
#' This function generates an interactive donut chart using SVG elements,
#' visually representing a numeric value within a defined scale.
#'
#' @param value Numeric value to be represented on the chart, within the range defined by \code{min_scale} and \code{max_scale}.
#' @param color Color used for the donut stroke (e.g., "#3498db").
#' @param suffix Text to be appended after the value (optional).
#' @param prefix Text to be prepended before the value (optional).
#' @param radius Radius of the donut chart.
#' @param margin Margin around the donut chart.
#' @param width Stroke width of the donut chart.
#' @param max_scale Maximum value of the scale. Default is 1.
#' @param min_scale Minimum value of the scale. Default is 0.
#' @param fill_color Fill color for the innermost circle of the donut chart. Default is "none".
#' @param base_color Color used for the background circle. Default is "rgba(0,0,0,0.1)".
#' @param style Additional inline CSS styles to be applied to the container div.
#'
#' @return A browsable HTML object containing the donut chart.
#'
#' @examples
#' # Example usage:
#' donut_chart(75, color = "#3498db", suffix = "%", prefix = "",
#'             radius = 30, margin = 5, width = 7.5, max_scale = 100)
#'
#' @import htmltools
#' @export
donut_chart <- function(value, color, suffix = "", prefix = "",
                        radius = 22.5, margin = 5, width = 5,
                        max_scale = 1, min_scale = 0,
                        fill_color = "none",
                        base_color = "rgba(0,0,0,0.1)",
                        style = "font-weight: bold; color: black;") {
  # Calculate chart dimensions (all units are in rem for relative scaling)
  diameter <- 2 * radius + 2 * width + 2 * margin
  center <- diameter / 2
  slice_length <- 2 * pi * radius
  slice_offset <- slice_length * (1 - ((value - min_scale) / (max_scale - min_scale)))

  # Create the SVG donut chart with three circles:
  # - A background circle with a light grey stroke.
  # - A foreground circle representing the value, with a colored stroke and dash offset for the fill effect.
  # - An innermost circle with a fill color.
  donut_chart_svg <- sprintf(
    '<svg width="%s" height="%s" style="transform: rotate(-90deg)" focusable="false">
      <circle cx="%s" cy="%s" r="%s" fill="none" stroke-width="%s" stroke="%s"></circle>
      <circle cx="%s" cy="%s" r="%s" fill="none" stroke-width="%s" stroke="%s"
       stroke-dasharray="%s" stroke-dashoffset="%s"></circle>
      <circle cx="%s" cy="%s" r="%s" fill="%s" stroke-width="0" stroke="rgba(0,0,0,0)"></circle>
    </svg>',
    diameter, diameter, center, center, radius, width, base_color,
    center, center, radius, width, color, slice_length, slice_offset,
    center, center, radius, fill_color
  )

  # Define the label; if value is NULL or NA, the label will be empty
  label_value <- if (is.null(value) || is.na(value)) "" else paste0(prefix, value, suffix)
  label <- sprintf(
    '<div style="position: absolute; top: 50%%; left: 50%%; transform: translate(-50%%, -50%%)">
      %s
    </div>',
    label_value
  )

  # Combine the SVG and the label into a container, applying additional inline styles.
  result_html <- sprintf(
    '<div style="display: inline-flex; position: relative; %s">
      %s
      %s
    </div>',
    style, donut_chart_svg, label
  ) |> htmltools::HTML()

  # Return a browsable HTML object for interactive display when in an interactive session,
  # otherwise return the HTML object.
  if (interactive()) {
    htmltools::browsable(result_html)
  } else {
    return(result_html)
  }
}
