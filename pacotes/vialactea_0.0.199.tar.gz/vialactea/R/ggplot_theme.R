#' ggplot theme
#'
#'
#'
#' @return apply theme to ggplot
#' @export
theme_sepe <- function(...) {
  if (knitr::is_latex_output()) return(theme(...))
  else {
    return(theme(...,
                 plot.background = element_rect(fill = "#f8f9fa"),
                 legend.background = element_rect(fill = "#f8f9fa"),
                 axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
                 axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0))
    ))
  }
}
