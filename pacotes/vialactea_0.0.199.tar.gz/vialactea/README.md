
<!-- README.md is generated from README.Rmd. Please edit that file -->

# vialactea

<!-- badges: start -->

![](https://img.shields.io/badge/devel%20version-0.0.1-blue.svg) 
![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)
<!-- badges: end -->

vialactea is an R package that offers a comprehensive suite of
customizable templates specifically designed for the [Strategic Projects
Secretariat](https://monitoramento.sepe.pe.gov.br/) of the Government of
Pernambuco. This package includes professionally crafted templates for
presentations, official documents, technical reports, press releases,
and Shiny applications. By utilizing vialactea, users can ensure
consistent, high-quality formatting and branding across all
communication and documentation platforms.

## Installation

You can install the development version of vialactea from
[GitHub](https://github.com/) with:

``` r
# install.packages("pak")
pak::pak("StrategicProjects/vialactea")
```
