# Criação de uma Página no Shiny para "Contratos"
# Este script define a estrutura de uma página no Shiny, com foco na seção "Contratos".
# Inclui estilização customizada, elementos de autenticação e uma barra de navegação com diversos itens.

### Carregamento de Pacotes:
#
#   - library(shiny): Carrega o framework Shiny para construção de aplicações web interativas em R.
#   - library(shinyjs): Adiciona funcionalidades JavaScript ao Shiny.
#   - library(waiter): Fornece efeitos de carregamento para melhorar a experiência do usuário.
#
### Definição da Página Segura:
#
#  - secure_app(): Função que configura a aplicação Shiny com autenticação, tema customizado e elementos de interface.
#  - tags_top: Cabeçalho da página de autenticação com logo.
#  - tags_bottom: Rodapé da página de autenticação com informações de contato.
#  - background: Define um estilo de fundo gradiente para a página de autenticação.
#
### Cabeçalhos de Autenticação:
#
# - head_auth: Inclusão de arquivos CSS específicos para a página de login.
#
### Página Principal:
#
# - page(): Define a estrutura principal da página "Contratos".
# - tags$head(): Inclusão de estilos CSS externos e fontes.
# - useShinyjs() e useWaiter(): Ativação das funcionalidades do shinyjs e waiter.
# - includeScript("www/script.js"): Inclusão de scripts JavaScript externos.
# - theme = fn_custom_theme(): Aplicação de um tema customizado.
# - conditionalPanel(): Painel condicional que exibe uma mensagem de carregamento quando a página está processando.
#
### Barra de Navegação:
#
# - page_navbar(): Configura a barra de navegação com itens de menu à esquerda e à direita.
# - ui_Exemplo("main") e ui_Sobre("main"): Exemplos de módulos da aplicação.
# - nav_spacer(): Espaçador entre os itens do menu.
# - nav_menu(): Menu de navegação com subitens.
# - nav_item(): Itens individuais de navegação, como links para a página inicial, GitHub e logout.

# Código Principal

## Carregamento de pacotes necessários
library(shiny)      # Framework para construir aplicativos web interativos em R
library(shinyjs)    # Permite a utilização de funcionalidades JavaScript no Shiny
library(waiter)     # Para efeitos de carregamento

# As bibliotecas para autenticação e temas customizados precisam ser definidas previamente.

# Definição da página segura
ui <- # Definição da barra de navegação e seus itens
  tagList(
    page_navbar(
      fillable = FALSE,
      lang = "pt",
      window_title = "Monitoramento &mdash; Dashboard",
      title = fn_navbar(link = "https://monitoramento.sepe.pe.gov.br",
                        class = "govpe-logo",
                        image = "images/hortensia.svg",
                        width = "50px"),
      id = "navbar",
      # Copywriter
      footer = fn_footer("Este aplicativo foi desenvolvido pela <a href='https://www.javierorracadeatcu.com'>Secretaria Executiva de Monitoramento Estratégica</a> com R + Shiny"),
      # Itens do menu à esquerda (Módulos)
      ui_Exemplo("ex"),
      ui_Sobre("about"),

      # Itens do menu à direita (Links úteis)
      nav_spacer(),
      nav_menu(
        title = "Dropdown",
        align = "right",
        ui_Item1("item-1"),
        ui_Item2("item-2")
      ),
      # Links definidos no arquivo helpers/navbar.R
      nav_item(link_home),
      nav_item(link_git),
      nav_item(link_logout)
    )
  )

##### Important

secure_front(ui)

