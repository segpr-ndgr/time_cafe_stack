# Lógica do Servidor para Aplicativo Shiny
# Este script organiza e define a lógica do servidor para um aplicativo Shiny,
# incluindo autenticação do usuário e carregamento de módulos para diferentes funcionalidades.

# Definição da função do servidor
function(input, output, session) {
  # Autenticação do usuário
  # Utiliza o módulo 'secure_server' para autenticar usuários. As credenciais são verificadas
  # usando a função 'check_creds', que deve ser definida externamente.

  auth <- secure_server(
    check_credentials = check_creds(sepe_datalake, key, session)
  )

  # Avisa se o aplicativo se encontra na "Autenticação" ou "Aplicação"
  observe({
    message(input$shinymanager_where)
  })

  # Caso queira colocar um aviso depois do login
  # observeEvent(input$lgnclick, {
  #   cat("\nClick:", auth$result, "\n")
  #   showModal(modalDialog(style = "z-index: 99999;",
  #     title = NULL,
  #     "This is a somewhat important message.",
  #     easyClose = TRUE,
  #     footer = NULL
  #   ))
  # })

  # Carregamento de Módulos
  # Módulos específicos para Despesas, Contratos, Aditivos e Empenhos são carregados.
  # Cada função 'server_*' corresponde a um módulo de servidor que lida com a lógica específica
  # de cada seção do aplicativo.
  server_Exemplo("ex")

  # Evento de Logout
  # Observa o evento de clique no botão de logout (input$logout) e recarrega a sessão,
  # efetivamente deslogando o usuário.
  observeEvent(input$logout, {
    session$reload()
  })

  # Encerramento da Sessão
  # Define uma ação a ser executada quando a sessão do cliente é encerrada.
  # Aqui, verifica-se se o ambiente é interativo e, se não for, desconecta do banco de dados.
  # A variável 'con' deve representar a conexão com o banco de dados, estabelecida externamente.
  session$onSessionEnded(function() {
    if (!is_interactive()) dbDisconnect(con)
  })
}
