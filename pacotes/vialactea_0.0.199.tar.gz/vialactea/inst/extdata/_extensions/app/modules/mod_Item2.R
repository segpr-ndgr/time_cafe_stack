# Função que cria a interface do usuário (UI) para o módulo "Item2"
ui_Item2 <- function(id) {
  ns <- NS(id)  # Cria um namespace específico para o módulo

  # Define um painel de navegação com o título "Exemplo"
  nav_panel(
    title = "Item 2",
    "Em construção"  # Mensagem de placeholder indicando que o conteúdo está em construção
  )
}

# Função que cria o servidor para o módulo "Item2"
server_Item2 <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns  # Cria um namespace específico para o módulo dentro da sessão
      # Lógica do servidor pode ser adicionada aqui
    }
  )
}
