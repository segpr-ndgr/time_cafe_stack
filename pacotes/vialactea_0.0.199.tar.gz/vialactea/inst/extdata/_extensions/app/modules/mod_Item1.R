ui_Item1 <- function(id) {
  ns <- NS(id)
  nav_panel(
    title = "Item 1",
    navset_card_tab(
      nav_panel(
        title = "Contratos",
        # card(
        full_screen = TRUE,
        # card_header("Diagrama de entidade e relacionamento",
        #             class = "bg-secondary"),
        # card_body(
        HTML('<blockquote class="blockquote text-dark">
                  “<em>True optimization</em> is the revolutionary contribution of modern research to decision&nbsp;processes” <br>
                  <footer style="color:black" class="quoteauthor" ontouchend="">
                  <p>— George B. Dantzig</p>
                  </footer></blockquote>'),
        div(
          style = "display: block;width: 80%;text-align: center;margin-left: auto;margin-right: auto;",
          pikchr('
/*
Código inicial. Para comentários em linha use \\ ou #
*/
len = 3mm
pi = 3.141593
pointrad = 0.01in
linerad = 1.5mm

define zpr {
    Czpr: circle rad len/2
    LzrpR: line from Czpr.e right .75*len*cos(pi/4)
    LzrpU: line from Czpr.e go .75*len heading 45
    LzrpD: line from Czpr.e go .75*len heading 135
    dot fill red at Czpr.w rad pointrad
}

define zpl {
    Czpl: circle rad len/2
    LzlpL: line from Czpl.w left .75*len*cos(pi/4)
    LzlpU: line from Czpl.w go .75*len heading -45
    LzlpD: line from Czpl.w go .75*len heading -135
    dot fill red at Czpl.e rad pointrad
    move to Czpl.e
}

define opl {
    Lopl0: line left len
    Lopl1: line from Lopl0.end - (0,len/2) up len
    LolpL: line from Lopl1.c left .75*len*cos(pi/4)
    LolpU: line from Lopl1.c go .75*len heading -45
    LolpD: line from Lopl1.c go .75*len heading -135
    dot fill red at Lopl0.e rad pointrad
}

define mal {
    Lmal0: line left len*(1 + .75*cos(pi/4))
    //Lmal1: line  from Lmal0.end - (0,len/2) up len
    LmapU: line from Lmal0.end + (.75*cos(pi/4)*len, 0) go .75*len heading -45
    LmapD: line from Lmal0.end + (.75*cos(pi/4)*len, 0) go .75*len heading -135
    dot fill red at Lmal0.e rad pointrad
}

define mar {
    Lmar0: line right len*(1 + .75*cos(pi/4))
    //Lmal1: line  from Lmal0.end - (0,len/2) up len
    LmarU: line from Lmar0.end - (.75*cos(pi/4)*len, 0) go .75*len heading 45
    LmarD: line from Lmar0.end - (.75*cos(pi/4)*len, 0) go .75*len heading 135
    dot fill red at Lmar0.w rad pointrad
}

define opr {
    Lopr0: line right len
    Lopr1: line  from Lopr0.end - (0,len/2) up len
    LolrL: line from Lopr1.c right .75*len*cos(pi/4)
    LolrU: line from Lopr1.c go .75*len heading 45
    LolrD: line from Lopr1.c go .75*len heading 135
    dot fill red at Lopr0.w rad pointrad
}

define oor {
    Loor0: line right len*(1 + .75*cos(pi/4))
    Loor1: line from Loor0.end - (.75*cos(pi/4)*len, len/2) up len
    Loor2: line from Loor0.end - (.75*cos(pi/4)*len/2, len/2) up len
    //Loor2: line from Loor0.start - (-len/2,len/2) up len
    dot fill red at Loor0.w rad pointrad
}


define osr {
    Losor0: line right len*(1 + .75*cos(pi/4))
    Losor1: line from Losor0.end - (.75*cos(pi/4)*len, len/2) up len
    //Losor2: line from Losor0.end - (len*0.7071068/2,len/2) up len
    //Loor2: line from Loor0.start - (-len/2,len/2) up len
    dot fill red at Losor0.w rad pointrad
}

define ool {
    Lool0: line left len*(1 + .75*cos(pi/4))
    Lool1: line from Lool0.end - (-.75*cos(pi/4)*len, len/2) up len
    Lool2: line from Lool0.end - (-.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Lool0.e rad pointrad
}

define osl {
    Lool0: line left len*(1 + .75*cos(pi/4))
    Lool1: line from Lool0.end + (0.75*cos(pi/4)*len, -len/2) up len
    //Lool2: line from Lool0.end - (-len*0.7071068/2,len/2) up len
    dot fill red at Lool0.e rad pointrad
}


define zol {
    [
    Czol: circle rad len/2
    Lzol0: line from Czol.w left .75*len*cos(pi/4)
    Lzol1: line from Lzol0.start - (0.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Czol.e rad pointrad
    ]
    move to last .e
}

define zor {
    Czor: circle rad len/2
    Lzor0: line from Czor.e right .75*len*cos(pi/4)
    Lzor1: line from Lzor0.start - (-0.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Czor.w rad pointrad
    move to  Czor.e
}

$dist = 9cm

Contratos: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Contratos"  bold fill 0xe5e5f5
Key:  box "Código Único e-Fisco" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Ano" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Ano da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Credor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
DKey: box "Documento do Credor" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código (Preenchido pela UG)" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Data de Adjudicação da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Data de Assinatura" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Data de Homologação da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Data de Inclusão" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Início da Vigência" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Fim da Vigência" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Número do Subcontrato" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Objeto da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Observação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Possui TAC?" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Situação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Status da Licitação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Tipo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
UGKey:box "Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Unidade Gestora da Licitação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Sigla da Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor Executado" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
]

move to Contratos.s down $dist/10

Aditivos: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Aditivos"  bold fill 0xe5f5f5
Key:  box "Código Único e-Fisco" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Início da Vigência" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Fim da Vigência"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor Total de Aditivos" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor Total de Reajustes"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Alteração Contratual" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
]


move to Contratos.ne right $dist/3
P2: dot invis

Empenhos: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Empenhos"  bold fill 0xf5e5f5
Key:  box "Código Único e-Fisco" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
CGKey:box "Código Global" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Natureza do Credor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "Nome Fantasia do Credor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Orgão Emissor do Credor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "Razão Social do Credor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Tipo do Documento do Credor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Data de Lançamento" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Data de Emissão"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Data e Hora de Geração" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Data e Hora da Assinatura"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Usuário da Assinatura" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Usuário da Inclusão"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Exercício"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
DKey: box "Documento do Credor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "CEO" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Despesa Gerencial"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Despesa Gerencial Detalhada" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Destinação do Recurso"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Código da Licitação" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Ordenador"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Observação"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Modalidade" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
PKey: box "Programa de Trabalho"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código de Reforço" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código do Empenho Reforçado"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
FKey: box "Fonte do Recurso"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Fonte do Recurso Detalhada" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Elemento"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Tipo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Natureza da Despesa" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Modalidade de Despesa"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Categoria" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Tipo de Despesa" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Unidade Gestora do Empenho"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
GDKey:box "Grupo de Despesa"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor Executado" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Valor Original"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor Anulado" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Valor Liquidado"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor Reforçado" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Valor Pago"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor Devolvido" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      //box "Nome da Função"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "Nome da Subfunção" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Nome do Programa"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "Nome da Ação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Nome da Subação"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "Nome da Fonte"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      //box "Nome da Fonte Detalhada"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
] with .n at P2


move to Aditivos.s down $dist/10
P0: dot invis

Itens: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Itens"  bold fill 0xe5e5a5
Key:  box "Código e-Fisco" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Código"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Descrição" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Unidade"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Preço Unitário" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Quantidade"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Preço Total" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
] with .n at P0


move to Empenhos.DKey.e right $dist/3 then up ((Itens.Entidade.e.y + .5*Itens.Key.n.y) - (Itens.Key.e.y + .5*Itens.Key.s.y)) + 0.17mm
P3: dot invis


Credor: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Credor"  bold fill 0xe5e5a5
Key:  box "Documento" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Tipo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Natureza"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Nome Fantasia" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Orgão Emissor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Razão Social" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Credor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "A"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "B" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
] with .n at P3


move to Empenhos.ne right $dist/3
P8: dot invis


Liquidacoes: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Liquidações"  bold fill 0xe5a5e5
Key:  box "Código Global" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
LKey: box "Código LE" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Data de Liquidação"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Ano" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Tipo"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Unidade Gestora"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "A"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "B" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
] with .n at P8

move to Empenhos.PKey.e right $dist/3 then up ((Credor.Entidade.e.y + .5*Credor.Key.n.y) - (Credor.Key.e.y + .5*Credor.Key.s.y)) + 0.17mm
P5: dot invis

Programas: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Estrutura Programática"  bold fill 0xe5e5a5
Key:  box "Programa de Trabalho" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Nome" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Ação"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Subação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Função"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Subfunção" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      //box "Credor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "A"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      //box "B" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
] with .n at P5


move to Programas.s down $dist/10 - 0.1mm
P6: dot invis


Budget: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Orçamento"  bold fill 0xa5f5a5
      box "Ano"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
PKey: box "Programa de Trabalho"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      //box "Ação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
Fkey: box "Fonte do Recurso"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
GDKey:box "Grupo de Despesa" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
UGKey:box "Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Orçamento Inicial"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Dotação Autorizada" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor Empenhado"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor Liquidado" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Valor Pago"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
] with .n at P6


move to Liquidacoes.ne right $dist/3
P9: dot invis

Pagamentos: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Pagamentos"  bold fill 0xa5e5f5
Key:  box "Código Global" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Banco" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Agência"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Conta" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Cheque"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Ano Referência" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Data" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Tipo"  ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Unidade Gestora"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
] with .n at P9

/*
IDEMPENHO
NUMEROEMPENHO
TIPO
NUMEROBANCO
NUMEROAGENCIA
NUMEROCONTA
NUMEROCHEQUE
ANOREFERENCIA
VALOR
DATA
ID_UNIDADE_GESTORA

*/
C1: [oor()] with .e at Contratos.Key.w
C2: [zpr()] with .e at Aditivos.Key.w
L1: line from C2.w left $dist/15 then up until even with C1.e then to C1.w rad linerad behind C1

C3: [ool()] with .w at Contratos.Key.e
C4: [zpr()] with .e at Empenhos.Key.w
line from C3.e right until even with .5<Contratos.c, Empenhos.c> then down until even with C4.e then right to C4.w rad linerad behind C3

C5: [opl()] with .w at Empenhos.DKey.e
C6: [oor()] with .e at Credor.Key.w
line from C5.e to C6.w behind C5

C7: [opr()] with .e at Itens.Key.w
line from C7.w left $dist/15 then up until even with Aditivos.n rad linerad behind C7

C8: [oor()] with .e at Programas.Key.w
C9: [ool()] with .w at Empenhos.PKey.e
line from C8.e to C9.e behind C8

C10: [osl()] with .w at Budget.PKey.e
C11: [osl()] with .w at Programas.Key.e
line from C10.e right $dist/15 then down until even with C11 then to C11 rad linerad behind C10

C12: [osl()] with .w at Contratos.UGKey.e
C13: [osr(?)] with .e at Budget.UGKey.w
line from C12.e right until even with .5<Contratos.ne, Empenhos.nw> then down until even with Empenhos.s - (0, $dist/10) then right until even with .5<C8, C9>  then up until even with C13  then to C13 rad linerad behind C12

C14: [osl()] with .w at Empenhos.GDKey.e
C15: [osr()] with .e at Budget.GDKey.w
line from C14 to C15 rad linerad behind C15

C16: [osr()] with .e at Budget.Fkey.w
C17: [osr()] with .w at Empenhos.FKey.e
line from C16.w left until even with last line.c then up until even with C17 then to C17 rad linerad behind C16


//BB: box with .nw at Liquidacoes.nw - (6mm, -6mm) wid Liquidacoes.ne.x - Liquidacoes.nw.x + 12mm ht Liquidacoes.n.y - Liquidacoes.s.y  + 12mm color 0xe5e5e5 fill 0xefefef behind Liquidacoes invis
BBL: line from Liquidacoes.nw - (6mm, -6mm) right until even with Pagamentos.ne + (6mm,6mm) then down until even with Pagamentos.sw + (6mm,-6mm) then left until even with Pagamentos.sw + (-6mm,-6mm) then up until even with Liquidacoes.se - (0, 6mm) then left until even with Liquidacoes.sw - (6mm,0) close color 0xe5e5e5 fill 0xefefef behind Liquidacoes

C18: [zpr()] with .e at Liquidacoes.Key.w
C19: [ool()] with .w at Empenhos.CGKey.e
line from C18.w right until even with .5<Empenhos.ne, Liquidacoes.nw>  then up until even with C19.w then to C19.e rad linerad behind C18

C20: [zpr()] with .e at Pagamentos.Key.w
line from C19.e right until even with .5<Empenhos.ne, Liquidacoes.nw>  then down until even with .5<Liquidacoes.sw, Credor.nw> then right until even with .5<Liquidacoes.ne, Pagamentos.nw> then up until even with C20.w then to C20.w rad linerad behind C20



"Consultar e-Fisco" above at BBL.n
"Conversar com Tiago Maranhão" italic below at BBL.n



',
            width = "100%",
            height = "auto",
            align = "center",
            fontFamily = "inherit"
          )
        )

        #     markdown('
        #  > "*True optimization* is the revolutionary contribution of modern research to decision&nbsp;processes"
        #  > `r quoteauthor("George B. Dantzig")`
        # ') #
      ),
      nav_panel(
        title = "Compras",
        # card(
        full_screen = TRUE,
        # card_header("Diagrama de entidade e relacionamento",
        #             class = "bg-secondary"),
        # card_body(
        HTML('<blockquote class="blockquote text-dark">
                  “<em>True optimization</em> is the revolutionary contribution of modern research to decision&nbsp;processes” <br>
                  <footer style="color:black" class="quoteauthor" ontouchend="">
                  <p>— George B. Dantzig</p>
                  </footer></blockquote>'),
        div(
          style = "display: block;width: 80%;text-align: center;margin-left: auto;margin-right: auto;",
          pikchr('

/*
Código inicial. Para comentários em linha use \\ ou #
*/
len = 3mm
pi = 3.141593
pointrad = 0.01in
linerad = 1.5mm

define zpr {
    Czpr: circle rad len/2
    LzrpR: line from Czpr.e right .75*len*cos(pi/4)
    LzrpU: line from Czpr.e go .75*len heading 45
    LzrpD: line from Czpr.e go .75*len heading 135
    dot fill red at Czpr.w rad pointrad
}

define zpl {
    Czpl: circle rad len/2
    LzlpL: line from Czpl.w left .75*len*cos(pi/4)
    LzlpU: line from Czpl.w go .75*len heading -45
    LzlpD: line from Czpl.w go .75*len heading -135
    dot fill red at Czpl.e rad pointrad
    move to Czpl.e
}

define opl {
    Lopl0: line left len
    Lopl1: line from Lopl0.end - (0,len/2) up len
    LolpL: line from Lopl1.c left .75*len*cos(pi/4)
    LolpU: line from Lopl1.c go .75*len heading -45
    LolpD: line from Lopl1.c go .75*len heading -135
    dot fill red at Lopl0.e rad pointrad
}

define mal {
    Lmal0: line left len*(1 + .75*cos(pi/4))
    //Lmal1: line  from Lmal0.end - (0,len/2) up len
    LmapU: line from Lmal0.end + (.75*cos(pi/4)*len, 0) go .75*len heading -45
    LmapD: line from Lmal0.end + (.75*cos(pi/4)*len, 0) go .75*len heading -135
    dot fill red at Lmal0.e rad pointrad
}

define mar {
    Lmar0: line right len*(1 + .75*cos(pi/4))
    //Lmal1: line  from Lmal0.end - (0,len/2) up len
    LmarU: line from Lmar0.end - (.75*cos(pi/4)*len, 0) go .75*len heading 45
    LmarD: line from Lmar0.end - (.75*cos(pi/4)*len, 0) go .75*len heading 135
    dot fill red at Lmar0.w rad pointrad
}

define opr {
    Lopr0: line right len
    Lopr1: line  from Lopr0.end - (0,len/2) up len
    LolrL: line from Lopr1.c right .75*len*cos(pi/4)
    LolrU: line from Lopr1.c go .75*len heading 45
    LolrD: line from Lopr1.c go .75*len heading 135
    dot fill red at Lopr0.w rad pointrad
}

define oor {
    Loor0: line right len*(1 + .75*cos(pi/4))
    Loor1: line from Loor0.end - (.75*cos(pi/4)*len, len/2) up len
    Loor2: line from Loor0.end - (.75*cos(pi/4)*len/2, len/2) up len
    //Loor2: line from Loor0.start - (-len/2,len/2) up len
    dot fill red at Loor0.w rad pointrad
}


define osr {
    Losor0: line right len*(1 + .75*cos(pi/4))
    Losor1: line from Losor0.end - (.75*cos(pi/4)*len, len/2) up len
    //Losor2: line from Losor0.end - (len*0.7071068/2,len/2) up len
    //Loor2: line from Loor0.start - (-len/2,len/2) up len
    dot fill red at Losor0.w rad pointrad
}

define ool {
    Lool0: line left len*(1 + .75*cos(pi/4))
    Lool1: line from Lool0.end - (-.75*cos(pi/4)*len, len/2) up len
    Lool2: line from Lool0.end - (-.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Lool0.e rad pointrad
}

define osl {
    Lool0: line left len*(1 + .75*cos(pi/4))
    Lool1: line from Lool0.end + (0.75*cos(pi/4)*len, -len/2) up len
    //Lool2: line from Lool0.end - (-len*0.7071068/2,len/2) up len
    dot fill red at Lool0.e rad pointrad
}


define zol {
    [
    Czol: circle rad len/2
    Lzol0: line from Czol.w left .75*len*cos(pi/4)
    Lzol1: line from Lzol0.start - (0.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Czol.e rad pointrad
    ]
    move to last .e
}

define zor {
    Czor: circle rad len/2
    Lzor0: line from Czor.e right .75*len*cos(pi/4)
    Lzor1: line from Lzor0.start - (-0.75*cos(pi/4)*len/2,len/2) up len
    dot fill red at Czor.w rad pointrad
    move to  Czor.e
}

$dist = 9cm

Licitacoes: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Licitações"  bold fill 0xc7eae4
      box "Número do Processo" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Ano do Processo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código do Pregão" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código da Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código Super Simples" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Tipo de Pregão" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Critério de Julgamento" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Objeto" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Documento da Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Nome da Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Data Inicial" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Data Final" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Data de Homolocação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Tipo de Apuração" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código da Situação" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Situação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Total de Propostas" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código do Critério" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Critério" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Comissão de Licitação" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Empresa Vencedora" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Documento da Empresa Vencedora" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Quantidade da Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Quantidade da Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Número do Lote" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Sequencial" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor Total" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor de Referência" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor Estimado no Processo" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor do Lance" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor Total Estimado" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
Key:  box "Código do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
]

move to Licitacoes.ne right $dist/3
P2: dot invis

Inexigibilidades: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Inexigibilidades"  bold fill 0xffd972
Key:  box "Número do Processo" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Ano do Processo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Código" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Número da Solicitação de Compra"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Unidade Compradora" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Objeto"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Data Inicial" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Data Final"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Data da Homologação" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Comissão de Licitação"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Modalidade" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Empresa Vencedora"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Documento da Empresa Vencedora" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Empresa Vencedora"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Quantidade da Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Quantidade da Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Número do Lote" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Sequencial" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Critério" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Fundamentação Legal" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Situação do Item" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor Total" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor do Melhor Lance" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Valor do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Valor da Economia" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
Key:  box "Código do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
] with .n at P2


move to Inexigibilidades.ne right $dist/3
P3: dot invis

Atas: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Atas"  bold fill 0xb2b09b
      box "Número da Ata" bold ljust small fit wid $dist/3 with .n at Entidade.s fill 0xf5f5f5
      box "Número do Processo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Ano da Ata" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Ano do Processo"  ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Ano da Ata" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Documento da Unidade Gestora" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Inicio da Vigência" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Término da Vigência" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Situação" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Objeto" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Lote" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Sequencial" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Fornecedor" ljust small fit wid $dist/3 with .n at last.s fill  0xffffff
      box "Documento do Fornecedor" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Quantidade da Unidade de Medida" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Quantidade da Unidade de Tempo" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Valor Unitário" ljust small fit wid $dist/3 with .n at last.s fill 0xffffff
      box "Valor de Referência" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5
      box "Quantidade de Consumo Autorizados" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Quantidade de Adesões Autorizadas" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
Key:  box "Código do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
] with .n at P3


move to Atas.se down $dist/6
P4: dot invis

Itens: [
Entidade: box rad 5mm  ht 5mm wid $dist/3 "Itens"  bold fill 0xffc8dd
Key:  box "Código do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Descrição do Item" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código do Grupo" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Descrição do Grupo" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código da Classe" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Descrição da Classe" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Código do Material ou Serviço" ljust small fit wid $dist/3 with .n at last.s  fill 0xffffff
      box "Descrição do Material ou Serviço" ljust small fit wid $dist/3 with .n at last.s fill 0xf5f5f5
      box "Situação do Item" ljust small fit wid $dist/3 with .n at last.s  fill 0xf5f5f5

] with .ne at P4

C1: [ool()] with .w at Licitacoes.Key.e
C2: [oor()] with .e at Inexigibilidades.Key.w
C3: [oor()] with .e at Atas.Key.w
C4: [oor()] with .e at Itens.Key.w

L1: line from C2.w left len then down until even with C1
L2: line from C1.e right until even with C3.w - (len, 0) then up until even with C3.w then right to C3.w
L3: line from C4.w left len

',
            width = "100%",
            height = "auto",
            align = "center",
            fontFamily = "inherit"
          )
        )
      )
    )
  )
}

server_Item1 <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
    }
  )
}
