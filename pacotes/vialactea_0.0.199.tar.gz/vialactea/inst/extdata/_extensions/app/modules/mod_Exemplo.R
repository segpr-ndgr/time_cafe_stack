ui_Exemplo <- function(id) {
  ns <- NS(id)
  nav_panel(
    title = "Monitor",
    card(
      full_screen = FALSE, fill = FALSE,
      card_header(
        div(
          class = "mlk-empenhos-header",
          h2(class = "emppenhos-title", "Valores Empenhados, liquidados e pagos por contrato"),
          HTML("Dados do XXX | Secretaria da XXXX | <span style='font-style: oblique;font-weight: 300'>Última atualização em 13/05/2024.</span>")
        )
      ),
      # card_header("Parâmetros", class = "bg-primary"),
      card_body(
          layout_column_wrap(
            fill = FALSE, # fixed_width = TRUE,
            width = 1 / 2,
            checkboxGroupInput(
              inputId = ns("filtros_check"), label = h5("Filtros"), inline = FALSE,
              choices = c("Por vigência", "Em execução"),
              selected = c("Por vigência", "Em execução")
            ),
            radioButtons(
              inputId = ns("validade_unidade"), label = h5("Unidade"),
              choices = c("dias", "meses", "anos"),
              selected = c("anos"), inline = TRUE,
            )
          ),
        hr(),
        layout_column_wrap(
          fill = FALSE,
          width = "320px",
          span(
            class = "mlk-emp",
            sliderInput(ns("frac_empenhado"),
              label = h5("Empenho"),
              width = "80%", min = 0, max = 100, post = "%",
              value = c(0, 100), step = 1, round = TRUE
            )
          ),
          span(
            class = "mlk-liq",
            sliderInput(ns("frac_liquidado"),
              label = h5("Liquidado"),
              width = "80%", min = 0, max = 100,
              value = c(0, 100), step = 1, round = TRUE,
              post = "%"
            )
          ),
          span(
            class = "mlk-pag",
            sliderInput(ns("frac_pago"),
              label = h5("Pagamento"),
              width = "80%", min = 0, max = 100, post = "%",
              value = c(0, 100), step = 1, round = TRUE
            )
          ),
          span(
            class = "mlk-vig",
            sliderInput(ns("intervalo_validade"),
              label = "Vigência (anos)",
              width = "80%", min = -5, max = 10,
              value = c(0, 10), step = 1, round = TRUE
            )
          )
        )
      )
    ),
    card(
      card_header(
        class = "d-flex justify-content-between",
        "Título",
        div(
          tags$a(
            class = "mlk-link mlk-pointer", style = "padding:0 5px;color:var(--bs-primary);", HTML("<i class=\"fas fa-circle-plus\" role=\"presentation\" aria-label=\"expand icon\"></i>")
          ),
          tags$a(
            class = "mlk-link mlk-pointer", style = "padding:0 5px;color:var(--bs-primary);", HTML("<i class=\"fas fa-eye\" role=\"presentation\" aria-label=\"view icon\"></i>")
          )
        )
      ),
      card_body(

        # )
      )
    )
  )
}

server_Exemplo <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns

      # Apenas para Teste. Remover!
      observeEvent(input$intervalo_validade, {
       Sys.sleep(2)
      })
    }
  )
}
