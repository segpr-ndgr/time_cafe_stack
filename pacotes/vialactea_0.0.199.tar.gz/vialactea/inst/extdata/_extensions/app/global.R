# # Sumário
# 1. Carregamento de Bibliotecas
# 2. Configuração YAML
# 3. Funções Genéricas
# 4. Funções de Autenticação
# 5. Leitura de Dados
# 6. Módulos


# 1. Carregamento de Bibliotecas -------------------------------------------------
# Carrega as bibliotecas necessárias para o funcionamento do script.
# As bibliotecas são usadas para manipulação de dados, criação de interfaces de usuário,
# manipulação de datas, conexão com bancos de dados, e mais.

library(rlang) # Ferramentas essenciais para a linguagem R
library(shiny) # Para criação de aplicativos web interativos
library(bslib) # Suporte a temas Bootstrap para Shiny
library(bsicons) # Ícones do Bootstrap para uso em Shiny
library(htmltools) # Ferramentas para manipulação de HTML
library(tidyverse) # Coleção de pacotes para ciência de dados
library(shinyjs) # Uso de JavaScript no Shiny
library(waiter) # Para carregamento e progresso em Shiny
library(httr) # Ferramentas para trabalhar com HTTP
library(DBI) # Interface de banco de dados para R
library(lubridate) # Para manipulação de datas
library(dbplyr) # Traduz consultas dplyr em SQL
#library(shinyWidgets) # Widgets personalizados para Shiny
library(shinycssloaders) # Carregadores CSS para Shiny
library(pals) # Paletas de cores
#library(sf) # Para manipulação de dados geográficos
#library(leaflet) # Para mapas interativos
#library(leaflet.extras) # Funcionalidades extras para Leaflet
library(viridis) # Paletas de cores para mapas e gráficos
library(shinymanager) # Autenticação para aplicativos Shiny
library(glue) # Interpolação de strings
library(safer) # Criptografia para R
require(config) # Carregamento de configurações
require(svglite) # Exportação de gráficos como SVG
library(reactable) # Tabelas interativas para Shiny
library(scales) # Escalas para ggplot2
library(jsonlite) # Trabalho com JSON
library(stringi) # Manipulação de strings
library(writexl) # Escrever dados em arquivos Excel
library(plotly) # Gráficos interativos
library(fst) # Leitura e escrita rápida de dados
library(tippy) # Dicas de ferramentas para Shiny
library(reactable.extras) # Extras para reactable
library(pikchr) # Desenho de diagramas em texto
library(arrow) # Leitura de arquivos Parquet e Feather
library(vialactea) # Funções do modelo da SEPE/SEME
# 2. Configuração YAML -----------------------------------------------------------
# Lê informações de configuração do arquivo YAML.

status <- config::get("status")
sepe_datalake <- config::get(paste0("sepedatalake_", status))
app_name <- config::get("app_name")
seed <- read_rds("data/semente.rds")
key <- safer::keypair(seed = seed)
keys <- read_rds("data/key_app_users.rds")

# 4. Funções de Autenticação -------------------------------------------------------
# Define funções para configuração de etiquetas de autenticação e verificação de credenciais.

# Função secure_front
# •	Objetivo: Criar uma aplicação Shiny segura com uma página de autenticação personalizada.
# •	Parâmetros:
#   •	ui: Interface do usuário a ser renderizada após a autenticação.
#   •	logo: Caminho para o logo a ser exibido na página de autenticação (padrão: “images/logo_sepe.png”).
# •	Detalhes:
#   •	Idioma: Define o idioma da aplicação como português do Brasil (language = "pt-BR").
#   •	Tema: Aplica um tema customizado definido na função fn_custom_theme().
#   •	Cabeçalho: Exibe um logo no cabeçalho da página de autenticação (tags_top).
#   •	Rodapé: Adiciona informações de contato no rodapé da página de autenticação (tags_bottom).
#   •	Estilo de fundo: Define um gradiente radial como fundo da página de autenticação (background).
#   •	Cabeçalhos de autenticação: Inclui um arquivo CSS para estilizar a página de login (head_auth).
#   •	Página principal: Define a estrutura da página principal, incluindo a aplicação de temas e a inclusão de scripts e estilos externos.
#   •	Feedback de carregamento: Utiliza shinyjs e waiter para mostrar uma mensagem de carregamento enquanto a aplicação está processando (conditionalPanel).

secure_front <- function(ui, logo = "images/logo_sepe.png") {
  secure_app(
    language = "pt-BR",
    theme = fn_custom_theme(),
    fab_position = "none",

    # Cabeçalho da página de autenticação
    tags_top = tags$div(
      tags$img(src = logo, width = '80%')
    ),

    # Informação adicional no rodapé da página de autenticação
    tags_bottom = tags$div(
      tags$p(
        "Qualquer dúvida, entrar em contato com o ",
        tags$a(
          href = "mailto:andre.leite@sepe.pe.gov.br?Subject=SEPE Apps",
          target="_top", "administrador"
        )
      )
    ),

    # Estilo de fundo para a página de autenticação
    background = "radial-gradient(circle at 22.4% 21.7%, rgb(238, 130, 238) 0%, rgb(127, 0, 255) 100.2%);",

    # Inclusão de cabeçalhos de autenticação
    head_auth = tagList(
      tags$link(rel = "stylesheet", type = "text/css", href = "login.css")
    ),

    # Definição da página principal
    page(
      title = app_name, # Modificar no config.yml
      # Inclusão de estilos CSS externos
      tags$head(
        tags$link(rel="stylesheet", href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200")
      ),

      # Utilização de shinyjs para funcionalidades JS
      useShinyjs(),

      # Utilização de waiter para feedback de carregamento
      useWaiter(),


      # Inclusão de scripts JavaScript externos
      includeScript("www/script.js"),


      # helpers
      theme = fn_custom_theme(),

      # Utilização de shinyjs e waiter para interatividade e feedback de carregamento
      conditionalPanel(
        condition = "$('html').hasClass('shiny-busy')",
          tags$div(
            id = "loadmessage",
            loadingImage()
          )
      ),
      ui
    )
  )
}


# set_labels
# Define rótulos personalizados para o sistema de autenticação em um aplicativo Shiny.
# Esta configuração é particularmente útil para internacionalização ou simplesmente para
# personalizar as mensagens de login exibidas aos usuários.
#
# Args:
#   language: Idioma para o qual os rótulos são definidos. Exemplo: "pt-BR" para Português do Brasil.
#   "Please authenticate": Mensagem pedindo autenticação. Pode ser deixada em branco ou personalizada.
#   "Username:": Rótulo para o campo de nome de usuário.
#   "Password:": Rótulo para o campo de senha.
set_labels(
  language = "pt-BR",
  "Please authenticate" = "",
  "Username:" = "Nome",
  "Password:" = "Senha"
)



# 5. Leitura, Limpeza e Tranformação de Dados --------------------------------------------------------------
# Lê dados de diversos arquivos e realiza manipulações iniciais.

# 5.1. Leitura de Dados -----------------------------------------------------------

# 5.2. Limpeza de Dados -----------------------------------------------------------
# Prefefir sempre um ETL separado


# 5.3. Enriquecimento e Transformação de Dados ------------------------------------
# Prefefir sempre um ETL separado


# Listas Auxiliares -------------------------------------------------------------
# Listas auxiliares são definidas para facilitar o mapeamento e a categorização de dados em análises.



# 6. Módulos -----------------------------------------------------------------------

# Carregamento Modular de Scripts R
# Este script automatiza o carregamento de múltiplos arquivos de script R localizados dentro dos diretórios 'modules' e 'helpers'.
# É útil em projetos maiores para organizar o código em módulos lógicos e facilitar a manutenção.

# Carregamento dos scripts ------------------------------------------------------
# A função dir_ls() do pacote fs é utilizada para listar todos os arquivos dentro dos diretórios especificados.
# A função map() do pacote purrr é então usada para iterar sobre cada caminho de arquivo e carregar o script correspondente
# utilizando a função source() do R.

file_paths <- fs::dir_ls(c("modules", "helpers"), invert = TRUE, regexp = ".*DONOTLOAD.*")
# Lista todos os arquivos nos diretórios 'modules' e 'helpers',
# que não contenham a expressão DONOTLOAD

map(file_paths, function(x) {
  source(x)  # Carrega cada arquivo individualmente.
})

# Notas ----------------------------------------------------------------------------
# - Certifique-se de que os diretórios 'modules' e 'helpers' existam no seu projeto e contenham os arquivos R a serem carregados.
# - Esta abordagem modulariza o projeto, permitindo uma organização clara do código em arquivos específicos de funções ou tarefas.
# - A ordem de carregamento dos scripts pode ser importante em casos onde um script depende de funções definidas em outro. Garanta
#   que as dependências entre os módulos sejam resolvidas corretamente, possivelmente ajustando a estrutura de diretórios ou o nome
#   dos arquivos para controlar a ordem de carregamento.


